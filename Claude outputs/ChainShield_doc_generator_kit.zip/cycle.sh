set -e
cd /home/claude/w
conv(){ (cd out && timeout 180 python3 /mnt/skills/public/docx/scripts/office/soffice.py --headless --convert-to pdf ChainShield_Documentation_Final_v2.docx >/dev/null 2>&1); }
python3 build_docx.py >/dev/null; conv; python3 pages.py >/dev/null
python3 build_docx.py >/dev/null; conv; cp pages.json p0.json; python3 pages.py; diff -q pages.json p0.json && echo STABLE
