# -*- coding: utf-8 -*-
import re, sys, json, os
sys.path.insert(0, "/home/claude/w")
from content import *
import content as C
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Emu
from docx.enum.text import WD_TAB_ALIGNMENT, WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "Times New Roman"
NAVY = RGBColor(0x1B, 0x2A, 0x4A)
PAGES = json.load(open("/home/claude/w/pages.json")) if os.path.exists("/home/claude/w/pages.json") else {}

doc = Document()
sec0 = doc.sections[0]
sec0.page_height, sec0.page_width = Inches(11.69), Inches(8.27)
sec0.left_margin = Inches(1.1); sec0.right_margin = Inches(0.9)
sec0.top_margin = Inches(0.9); sec0.bottom_margin = Inches(0.9)
sec0.header_distance = Inches(0.4); sec0.footer_distance = Inches(0.4)
CONTENT_W = 8.27 - 2.0

def set_font(style, size, bold=False, color=None, italic=False):
    style.font.name = FONT; style.font.size = Pt(size); style.font.bold = bold; style.font.italic = italic
    rpr = style.element.get_or_add_rPr()
    rf = rpr.find(qn("w:rFonts"))
    if rf is None: rf = OxmlElement("w:rFonts"); rpr.append(rf)
    for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"): rf.set(qn(a), FONT)
    for a in ("w:asciiTheme", "w:hAnsiTheme", "w:cstheme", "w:eastAsiaTheme"):
        if rf.get(qn(a)) is not None: del rf.attrib[qn(a)]
    if color is not None: style.font.color.rgb = color

st = doc.styles
set_font(st["Normal"], 12)
st["Normal"].paragraph_format.space_after = Pt(6)
st["Normal"].paragraph_format.line_spacing = 1.5
set_font(st["Heading 1"], 16, True, NAVY)
h1 = st["Heading 1"].paragraph_format; h1.space_before = Pt(0); h1.space_after = Pt(12); h1.keep_with_next = True
set_font(st["Heading 2"], 14, True, NAVY)
h2 = st["Heading 2"].paragraph_format; h2.space_before = Pt(12); h2.space_after = Pt(6); h2.keep_with_next = True
set_font(st["Heading 3"], 12, True, RGBColor(0, 0, 0))
h3 = st["Heading 3"].paragraph_format; h3.space_before = Pt(8); h3.space_after = Pt(4); h3.keep_with_next = True
for s in ("Heading 1", "Heading 2", "Heading 3"):
    st[s].paragraph_format.line_spacing = 1.15

def bottom_border(p, color="1B2A4A", sz=12):
    pPr = p._p.get_or_add_pPr(); b = OxmlElement("w:pBdr"); e = OxmlElement("w:bottom")
    e.set(qn("w:val"), "single"); e.set(qn("w:sz"), str(sz)); e.set(qn("w:space"), "4"); e.set(qn("w:color"), color)
    b.append(e); pPr.append(b)

def add_runs(p, text, size=None, bold=False, italic=False, color=None):
    parts = re.split(r"(\*\*[^*]+\*\*)", text)
    for part in parts:
        if not part: continue
        b = part.startswith("**")
        r = p.add_run(part[2:-2] if b else part)
        r.bold = bold or b; r.italic = italic
        if size: r.font.size = Pt(size)
        if color: r.font.color.rgb = color
        r.font.name = FONT
    return p

def para(text, align=WD_ALIGN_PARAGRAPH.JUSTIFY, **kw):
    p = doc.add_paragraph(); p.alignment = align; add_runs(p, text, **kw); return p

def page_break():
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

def shade(cell, hexcolor):
    tcPr = cell._tc.get_or_add_tcPr(); s = OxmlElement("w:shd")
    s.set(qn("w:val"), "clear"); s.set(qn("w:color"), "auto"); s.set(qn("w:fill"), hexcolor); tcPr.append(s)

def cell_text(cell, text, size=10.5, bold=False, color=None, align=WD_ALIGN_PARAGRAPH.LEFT):
    cell.text = ""
    lines = str(text).split("\n")
    for i, line in enumerate(lines):
        p = cell.paragraphs[0] if i == 0 else cell.add_paragraph()
        p.alignment = align
        pf = p.paragraph_format; pf.space_after = Pt(1); pf.space_before = Pt(1); pf.line_spacing = 1.0
        add_runs(p, line, size=size, bold=bold, color=color)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER

def repeat_header(row):
    trPr = row._tr.get_or_add_trPr(); e = OxmlElement("w:tblHeader"); e.set(qn("w:val"), "true"); trPr.append(e)

def no_split(row):
    trPr = row._tr.get_or_add_trPr(); e = OxmlElement("w:cantSplit"); e.set(qn("w:val"), "true"); trPr.append(e)

def set_widths(table, widths):
    table.autofit = False
    tbl = table._tbl; grid = tbl.tblGrid
    for i, gc in enumerate(grid.findall(qn("w:gridCol"))):
        if i < len(widths): gc.set(qn("w:w"), str(int(widths[i] * 1440)))
    for row in table.rows:
        for i, c in enumerate(row.cells):
            if i < len(widths): c.width = Inches(widths[i])

def caption(text):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(4); p.paragraph_format.space_after = Pt(10)
    add_runs(p, text, size=11, bold=True, italic=False)
    return p

def table(headers, rows, widths=None, caption_text=None, font=10.5, shade_first_col=False):
    if caption_text:
        cp = caption(caption_text); cp.paragraph_format.keep_with_next = True
        cp.paragraph_format.space_after = Pt(4)
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; cell_text(c, h, size=font, bold=True, color=RGBColor(255, 255, 255)); shade(c, "1B2A4A")
    repeat_header(t.rows[0])
    for r in rows:
        cells = t.add_row().cells
        for i, v in enumerate(r):
            cell_text(cells[i], v, size=font, bold=(shade_first_col and i == 0))
            if shade_first_col and i == 0: shade(cells[i], "E8F0FB")
    for row in t.rows: no_split(row)
    if len(t.rows) <= 13:
        for row in t.rows[:-1]:
            for c in row.cells:
                for p in c.paragraphs: p.paragraph_format.keep_with_next = True
    if widths: set_widths(t, widths)
    sp = doc.add_paragraph(); sp.paragraph_format.space_after = Pt(4); sp.paragraph_format.line_spacing = 1.0
    return t

def image(path, cap, width):
    from PIL import Image as PI
    w, h = PI.open(path).size
    width = min(width, CONTENT_W)
    if h / w * width > 8.3: width = 8.3 * w / h   # keep inside page height
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True; p.paragraph_format.space_after = Pt(2); p.paragraph_format.line_spacing = 1.0
    p.add_run().add_picture(path, width=Inches(width))
    # thin border around screenshots
    caption(cap)

def bullets(items, numbered=False):
    for k, it in enumerate(items, 1):
        p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        pf = p.paragraph_format; pf.left_indent = Inches(0.35); pf.first_line_indent = Inches(-0.25); pf.space_after = Pt(4)
        r = p.add_run(f"{k}.\t" if numbered else "•\t"); r.font.name = FONT
        pf.tab_stops.add_tab_stop(Inches(0.35))
        add_runs(p, it)

def gantt():
    weeks = len(MONTHS) * 4
    cap = caption("Fig 1.1 — Proposed Time Line Chart (Aug – Nov 2026)"); cap.paragraph_format.keep_with_next = True
    t = doc.add_table(rows=2, cols=2 + weeks); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    r0, r1 = t.rows
    cell_text(r0.cells[0].merge(r1.cells[0]), "Sr.", 10, True, RGBColor(255, 255, 255), WD_ALIGN_PARAGRAPH.CENTER)
    cell_text(r0.cells[1].merge(r1.cells[1]), "Phase", 10, True, RGBColor(255, 255, 255))
    for c in (r0.cells[0], r0.cells[1]): shade(c, "1B2A4A")
    for m, name in enumerate(MONTHS):
        mc = r0.cells[2 + m * 4].merge(r0.cells[2 + m * 4 + 3])
        cell_text(mc, name + " 2026", 10, True, RGBColor(255, 255, 255), WD_ALIGN_PARAGRAPH.CENTER); shade(mc, "1B2A4A")
        for w in range(4):
            c = r1.cells[2 + m * 4 + w]; cell_text(c, f"W{w+1}", 7, True, align=WD_ALIGN_PARAGRAPH.CENTER); shade(c, "D9E2F1")
    repeat_header(r0); repeat_header(r1)
    for i, (phase, (sm, sw), (em, ew)) in enumerate(GANTT_ROWS, 1):
        cells = t.add_row().cells
        cell_text(cells[0], str(i), 10, align=WD_ALIGN_PARAGRAPH.CENTER); cell_text(cells[1], phase, 10)
        a, b = sm * 4 + sw - 1, em * 4 + ew - 1
        for k in range(weeks):
            cell_text(cells[2 + k], "", 6)
            if a <= k <= b: shade(cells[2 + k], "2E5AAC")
    for row in t.rows: no_split(row)
    for row in t.rows[:-1]:
        for c in row.cells:
            for p in c.paragraphs: p.paragraph_format.keep_with_next = True
    tblPr = t._tbl.tblPr; mar = OxmlElement("w:tblCellMar")
    for side in ("left", "right"):
        e = OxmlElement(f"w:{side}"); e.set(qn("w:w"), "15"); e.set(qn("w:type"), "dxa"); mar.append(e)
    tblPr.append(mar)
    for row in t.rows[2:]: cell_text(row.cells[1], row.cells[1].text, 10); row.cells[1].paragraphs[0].paragraph_format.left_indent = Inches(0.04)
    set_widths(t, [0.35, 1.95] + [0.245] * weeks)
    p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
    add_runs(p, "Note: W1 = days 1–7, W2 = 8–14, W3 = 15–21, W4 = 22 to month-end. Shaded cells show the weeks in which each phase is carried out.", size=10, italic=True)

def fld(run, instr):
    for t_, v in (("begin", None), ("instr", instr), ("end", None)):
        if t_ == "instr":
            e = OxmlElement("w:instrText"); e.set(qn("xml:space"), "preserve"); e.text = instr
        else:
            e = OxmlElement("w:fldChar"); e.set(qn("w:fldCharType"), t_)
        run._r.append(e)

def header_footer(section):
    section.different_first_page_header_footer = True
    hp = section.header.paragraphs[0]; hp.text = ""
    for x in (3.25, 6.5): hp.paragraph_format.tab_stops.add_tab_stop(Inches(x), WD_TAB_ALIGNMENT.CLEAR)
    hp.paragraph_format.tab_stops.add_tab_stop(Inches(CONTENT_W), WD_TAB_ALIGNMENT.RIGHT)  # right
    add_runs(hp, f"{TITLE}\tMCA Semester 3 | {INSTITUTE}", size=9, color=RGBColor(0x55, 0x55, 0x55))
    bottom_border(hp, "999999", 6)
    fp = section.footer.paragraphs[0]; fp.text = ""
    for x in (3.25, 6.5): fp.paragraph_format.tab_stops.add_tab_stop(Inches(x), WD_TAB_ALIGNMENT.CLEAR)
    fp.paragraph_format.tab_stops.add_tab_stop(Inches(CONTENT_W), WD_TAB_ALIGNMENT.RIGHT)
    add_runs(fp, "Prepared By: Bhavik A. Visani, Diya Shah, Shruti Somani (Group 59)\tPage ", size=9, color=RGBColor(0x55, 0x55, 0x55))
    r = fp.add_run(); r.font.size = Pt(9); r.font.name = FONT; fld(r, "PAGE")

def heading(text, level):
    p = doc.add_heading(text, level=level)
    if level == 1: bottom_border(p)
    return p

# ================================================================ COVER
header_footer(sec0)
def cpara(text, size, bold=False, before=0, after=4, italic=False, color=None):
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(before); p.paragraph_format.space_after = Pt(after); p.paragraph_format.line_spacing = 1.15
    add_runs(p, text, size=size, bold=bold, italic=italic, color=color); return p
cpara("A PROJECT REPORT ON", 14, True, before=60)
cpara(f"“{TITLE.upper()}”", 22, True, before=6, color=NAVY)
cpara(SUBTITLE, 13, italic=True, after=40)
cpara("Submitted in Fulfillment of the Requirement", 13)
cpara("for Completion of Semester – 3 in", 13)
cpara("Master of Computer Application (MCA)", 14, True)
cpara(f"Academic Year {YEAR}", 13, after=40)
cpara("To", 13)
cpara(INSTITUTE.upper(), 15, True)
cpara(f"Affiliated to {UNIVERSITY}", 13, after=60)
t = doc.add_table(rows=1, cols=2); t.alignment = WD_TABLE_ALIGNMENT.CENTER
cell_text(t.cell(0, 0), f"**Guided By:**\n{GUIDE}", 12)
cell_text(t.cell(0, 1), f"**Prepared By: ({GROUP})**\n" + "\n".join(f"{n} ({r} – {e})" for n, r, e in MEMBERS), 12)
set_widths(t, [2.4, 3.8])
for c in t.rows[0].cells: c.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
page_break()

# ================================================================ FRONT MATTER
heading("DECLARATION", 1)
para(f"We, the undersigned students of {GROUP}, Master of Computer Application (MCA) Semester 3 at {INSTITUTE} (affiliated to {UNIVERSITY}), hereby declare that the project entitled “{TITLE}” is our own original work, carried out under the guidance of {GUIDE}, and has not been submitted, in whole or in part, for the award of any other degree, diploma, or certificate to this or any other institute or university.")
para("We further declare that all the information, technical concepts, and design decisions presented in this report have been gathered, analysed, and implemented by us to the best of our understanding, and that any reference material used has been duly acknowledged in the Bibliography.")
doc.add_paragraph()
t = doc.add_table(rows=1, cols=2); cell_text(t.cell(0, 0), "Date: __________________", 12); cell_text(t.cell(0, 1), "Place: Ahmedabad", 12)
doc.add_paragraph(); doc.add_paragraph()
for n, r, e in MEMBERS: para(f"**{n} ({r})**\t\t____________________", align=WD_ALIGN_PARAGRAPH.LEFT)
page_break()

heading("CERTIFICATE", 1)
para(f"This is to certify that the project entitled “{TITLE}”, submitted for MCA Semester 3, has been carried out by Bhavik A. Visani (D51), Diya Shah (D36), and Shruti Somani (D42) of {GROUP}, under my guidance and supervision.")
para("The work presented in this report is a bona fide record of the project carried out by the above-named students and, to the best of my knowledge, has not been submitted elsewhere for the award of any degree or diploma.")
para("I wish them success in their future endeavours.")
for _ in range(4): doc.add_paragraph()
t = doc.add_table(rows=1, cols=2)
cell_text(t.cell(0, 0), f"_______________________________\n**{GUIDE}**\nProject Guide", 12)
cell_text(t.cell(0, 1), f"_______________________________\n**Head of Department / Director**\n{INSTITUTE}", 12)
page_break()

heading("PREFACE", 1)
for x in [
 "Global trade today moves through supply chains of extraordinary scale and complexity — millions of shipments crossing ports, highways, railways, and air corridors every single day. The same forces that make this scale possible also make it fragile: a single storm, a congested port, or a mishandled hazardous cargo shipment can ripple into delays that cost businesses time, money, and customer trust. Historically, these disruptions have been discovered only after the fact, when a delivery has already slipped past its promised window.",
 "This project, ChainShield Transportation System, was conceived to address exactly that gap. Rather than treating disruption management as a reactive, after-the-event exercise, ChainShield continuously evaluates every active shipment against a weighted risk model, flags the ones heading toward trouble, and proposes concrete rerouting alternatives before the delay materialises.",
 "The idea came from a practical observation: most logistics teams still learn about a delay only after it has happened. We set out to build ChainShield as a lean, self-hostable product — Python (Flask), SQLite, server-rendered Jinja2/Bootstrap templates and Docker — that any logistics company can run on its own server without paid services or a complex cloud setup, while still delivering real-time risk scoring, route recommendations and alerts.",
 f"This report documents the problem definition, requirement analysis, system design, implementation, and testing of the ChainShield Transportation System, prepared as part of the curriculum prescribed for MCA Semester 3 at {INSTITUTE}."]:
    para(x)
page_break()

heading("ACKNOWLEDGEMENT", 1)
for x in [
 "We would like to express our sincere gratitude to everyone who supported us through the course of this project.",
 f"First and foremost, we thank {UNIVERSITY} and {INSTITUTE} for providing us the opportunity and the academic environment to undertake this project as part of our MCA Semester 3 curriculum.",
 f"We are deeply grateful to our project guide, {GUIDE}, for his valuable guidance, constructive feedback, and constant encouragement throughout the planning, design, and documentation of this project. His inputs have been instrumental in shaping the direction of {TITLE}.",
 f"We also extend our thanks to the Director and faculty of {INSTITUTE} for their support, and to our classmates and peers who offered helpful suggestions during discussions on this project.",
 "Finally, we thank our families for their patience and encouragement throughout this endeavour."]:
    para(x)
doc.add_paragraph()
para("Thank you,", align=WD_ALIGN_PARAGRAPH.LEFT)
para("**Bhavik A. Visani, Diya Shah, Shruti Somani**", align=WD_ALIGN_PARAGRAPH.LEFT)
para(f"{GROUP}, MCA Semester 3", align=WD_ALIGN_PARAGRAPH.LEFT)
page_break()

# ================================================================ INDEX
heading("INDEX", 1)
chapters = [s for s in S if s["level"] == 1]
rows = []
for ch in chapters:
    subs = [s for s in S if s["level"] == 2 and s["num"].split(".")[0] == ch["num"]]
    rows.append((ch["num"], f"**{ch['title'].title().replace('And', 'and')}**", str(PAGES.get(ch["num"], ""))))
    for s in subs:
        rows.append(("", f"      {s['num']}  {s['title']}", str(PAGES.get(s["num"], ""))))
t = doc.add_table(rows=1, cols=3); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
for i, h in enumerate(["Sr. No.", "Particulars", "Page No."]):
    cell_text(t.rows[0].cells[i], h, 12, True, RGBColor(255, 255, 255), WD_ALIGN_PARAGRAPH.CENTER); shade(t.rows[0].cells[i], "1B2A4A")
for a, b, c in rows:
    cs = t.add_row().cells
    cell_text(cs[0], a, 12, align=WD_ALIGN_PARAGRAPH.CENTER); cell_text(cs[1], b, 12); cell_text(cs[2], c, 12, align=WD_ALIGN_PARAGRAPH.CENTER)
set_widths(t, [0.9, 4.3, 1.0])

# ================================================================ BODY
for s in S:
    if s["level"] == 1:
        page_break()
        heading(f"{s['num']}. {s['title']}", 1)
    else:
        heading(f"{s['num']} {s['title']}", 2)
    for blk in s["doc"]:
        k = blk[0]
        if k == "p": para(blk[1])
        elif k == "h3": doc.add_heading(blk[1], level=3)
        elif k == "bullets": bullets(blk[1])
        elif k == "numbers": bullets(blk[1], numbered=True)
        elif k == "table":
            d = blk[1]; table(d["headers"], d["rows"], d["widths"], d["caption"], d["font"], d["shade_first_col"])
        elif k == "img": image(blk[1], blk[2], blk[3])
        elif k == "gantt": gantt()
        elif k == "pagebreak": page_break()

out = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/w/out/ChainShield_Documentation_Final_v2.docx"
os.makedirs(os.path.dirname(out), exist_ok=True)
doc.save(out); print("saved", out)
