import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, Rectangle, FancyArrowPatch, Polygon
plt.rcParams["font.family"]="Liberation Serif"
fig,ax=plt.subplots(figsize=(12,16.5)); ax.set_xlim(0,15); ax.set_ylim(-1.6,16.2); ax.axis("off")
INK="#1b2a4a"; FILL="#e8f0fb"; EW,EH=3.5,0.72
LX,RX=5.3,10.6
def actor(x,y,name,sub=None):
    ax.add_patch(plt.Circle((x,y+0.55),0.2,fill=False,lw=1.6,color=INK))
    ax.plot([x,x],[y+0.35,y-0.25],color=INK,lw=1.6)
    ax.plot([x-0.35,x+0.35],[y+0.15,y+0.15],color=INK,lw=1.6)
    ax.plot([x,x-0.3],[y-0.25,y-0.75],color=INK,lw=1.6); ax.plot([x,x+0.3],[y-0.25,y-0.75],color=INK,lw=1.6)
    ax.text(x,y-0.95,name,ha="center",va="top",fontsize=14,fontweight="bold",color=INK)
    if sub: ax.text(x,y-1.3,sub,ha="center",va="top",fontsize=11,color=INK,style="italic")
def uc(x,y,t):
    ax.add_patch(Ellipse((x,y),EW,EH,fc=FILL,ec=INK,lw=1.4)); ax.text(x,y,t,ha="center",va="center",fontsize=12.5,color="#0d1a33")
def assoc(ax_,ay,x,y,side="L"):
    ex = x-EW/2 if side=="L" else x+EW/2
    ax.plot([ax_,ex],[ay,y],color=INK,lw=1.2)
def dashed(x1,y1,x2,y2,label,lx,ly):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle="-|>",mutation_scale=18,lw=1.3,ls=(0,(5,4)),color=INK))
    ax.text(lx,ly,label,ha="center",va="center",fontsize=12,color=INK,style="italic",bbox=dict(fc="white",ec="none",pad=1))
# boundary
ax.add_patch(Rectangle((3.2,-1.25),9.4,17.0,fill=False,lw=1.8,ec=INK))
ax.text(7.9,15.45,"ChainShield Transportation System",ha="center",fontsize=16,fontweight="bold",color=INK)
bands={
 "Admin":(1.3,13.2,["Manage Users","Manage Hubs & Cargo Types","Configure System Settings","View Activity Audit Log"],14.6),
 "Manager":(1.3,8.0,["Manage Shipments","Review Disruptions","Apply Route Solution","View Reports","Ask AI Assistant","Trigger Demo Disruption"],10.4),
 "Field Operator":(1.3,1.9,["Login","View Assigned Shipments","Update Shipment Status","View Live Map","Chat with Users","Receive Notifications"],4.3),
}
pos={}
for name,(x,y,cases,top) in bands.items():
    sub={"Field Operator":"(Driver / Captain /\nPilot / Loco Pilot)"}.get(name)
    actor(x,y,name,sub)
    for i,c in enumerate(cases):
        cy=top-i*0.95; uc(LX,cy,c); pos[c]=(LX,cy); assoc(x+0.4,y+0.15,LX,cy)
# generalization (specialised actor -> general actor), straight vertical lines
def gen(x,y1,y2):
    ax.plot([x,x],[y1,y2+0.28],color=INK,lw=1.3)
    ax.add_patch(Polygon([[x,y2],[x-0.17,y2+0.3],[x+0.17,y2+0.3]],closed=True,fc="white",ec=INK,lw=1.3))
gen(1.3,13.2-1.35,8.0+0.8)
gen(1.3,8.0-1.35,1.9+0.8)
# scheduler (system actor) on the right
actor(14.1,13.35,"Scheduler","«system timer»")
uc(RX,14.6,"Scan Shipment Risk"); uc(RX,13.2,"Detect & Escalate Disruption"); uc(RX,11.5,"Generate Route Solutions")
assoc(14.1-0.4,13.5,RX,14.6,"R"); assoc(14.1-0.4,13.5,RX,13.2,"R")
dashed(RX,13.2-EH/2,RX,11.5+EH/2,"«include»",RX+0.95,12.35)
uc(RX,pos["View Reports"][1],"Export Report (CSV)")
y=pos["View Reports"][1]
dashed(RX-EW/2,y,LX+EW/2,y,"«extend»",(RX+LX)/2,y+0.32)
# legend
ax.text(7.9,-1.6,"Solid line = association   |   Hollow triangle = generalization (Admin → Manager → Field Operator)\nDashed arrow = «include» (always performed)  /  «extend» (optional)",ha="center",fontsize=11,color="#333",va="top")
plt.savefig("/home/claude/w/img/usecase.png",dpi=170,bbox_inches="tight",facecolor="white")
