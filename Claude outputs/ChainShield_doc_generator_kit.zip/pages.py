import subprocess, json, sys, re
sys.path.insert(0,"/home/claude/w"); from content import S
pdf="/home/claude/w/out/ChainShield_Documentation_Final_v2.pdf"
n=int(re.search(r"Pages:\s+(\d+)",subprocess.run(["pdfinfo",pdf],capture_output=True,text=True).stdout).group(1))
texts=[subprocess.run(["pdftotext","-f",str(i),"-l",str(i),"-layout",pdf,"-"],capture_output=True,text=True).stdout for i in range(1,n+1)]
pages={}; start=6
for s in S:
    key=f"{s['num']}. {s['title']}" if s["level"]==1 else f"{s['num']} {s['title']}"
    for i in range(start,n):
        lines=[l.strip() for l in texts[i].splitlines()]
        if any(l.startswith(key) for l in lines):
            pages[s["num"]]=i+1; start=i; break
    else: print("missing",key)
json.dump(pages,open("/home/claude/w/pages.json","w")); print(pages)
