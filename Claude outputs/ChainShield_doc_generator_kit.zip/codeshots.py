from pygments import highlight
from pygments.lexers import PythonLexer, HtmlDjangoLexer, TextLexer
from pygments.formatters import ImageFormatter
from PIL import Image, ImageDraw, ImageFont
import io
SRC="/home/claude/w/src/chainshield-mca/"
shots=[ # key, file, start, end, lexer
 ("cs1_pep8","app/services/risk_engine.py",32,52,PythonLexer),
 ("cs2_factory","app/__init__.py",15,26,PythonLexer),
 ("cs3_blueprints","app/__init__.py",129,144,PythonLexer),
 ("cs4_config","app/config.py",7,21,PythonLexer),
 ("cs5_orm","app/models.py",15,34,PythonLexer),
 ("cs6_validation","app/forms.py",10,30,PythonLexer),
 ("cs7_security","app/blueprints/shipments/routes.py",18,30,PythonLexer),
 ("cs8_templates","app/templates/_macros.html",1,7,HtmlDjangoLexer),
 ("cs9_requirements","requirements.txt",1,13,TextLexer),
]
F="/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
def render(key,f,a,b,lx):
    lines=open(SRC+f,encoding="utf-8").read().splitlines()[a-1:b]
    code="\n".join(l for l in lines)
    png=highlight(code,lx(),ImageFormatter(font_name="DejaVu Sans Mono",font_size=22,line_numbers=True,
        line_number_start=a,style="vs",line_number_bg="#f3f3f3",line_number_fg="#999999",image_pad=14,line_pad=4))
    body=Image.open(io.BytesIO(png)).convert("RGB")
    W=max(body.width,1100); bar=46
    im=Image.new("RGB",(W+2,body.height+bar+2),"#c8c8c8")
    inner=Image.new("RGB",(W,body.height+bar),"white"); d=ImageDraw.Draw(inner)
    d.rectangle([0,0,W,bar],fill="#e8e8e8")
    for i,c in enumerate(["#ff5f57","#febc2e","#28c840"]): d.ellipse([16+i*26,15,32+i*26,31],fill=c)
    d.text((110,11),f"chainshield-mca/{f}  —  lines {a}-{b}",fill="#333",font=ImageFont.truetype(F,20))
    inner.paste(body,(0,bar)); im.paste(inner,(1,1)); im.save(f"/home/claude/w/img/{key}.png")
for s in shots: render(*s)
print("ok")
