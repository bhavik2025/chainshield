# -*- coding: utf-8 -*-
"""Single source of content for the ChainShield report (descriptive) and PPT (point-wise).
Every section has `doc` blocks (descriptive, for Word) and `ppt` (short points, same order)."""

IMG = "/home/claude/w/img/"

TITLE = "ChainShield Transportation System"
SUBTITLE = "Real-Time Disruption Prediction & Route Optimisation for Logistics"
GROUP = "Group No. 59"
MEMBERS = [("Bhavik A. Visani", "D51", "25004401110170"),
           ("Diya Shah", "D36", "25003401110017"),
           ("Shruti Somani", "D42", "25004401110259")]
GUIDE = "Prof. Dhaval Shah"
INSTITUTE = "LJ Institute of Computer Application"
UNIVERSITY = "LJK University"
YEAR = "2026-27"

# ---------------------------------------------------------------- block helpers
def P(t): return ("p", t)
def H3(t): return ("h3", t)
def B(*items): return ("bullets", list(items))
def N(*items): return ("numbers", list(items))
def T(headers, rows, widths=None, caption=None, font=10.5, shade_first_col=False):
    return ("table", dict(headers=headers, rows=rows, widths=widths, caption=caption, font=font, shade_first_col=shade_first_col))
def I(name, caption, width=6.2): return ("img", IMG + name, caption, width)
def GANTT(): return ("gantt",)
PB = ("pagebreak",)

# ---------------------------------------------------------------- timeline data
MONTHS = ["Aug", "Sep", "Oct", "Nov"]
# phase, (start month idx, start week 1-4), (end month idx, end week)
GANTT_ROWS = [
    ("Requirement Gathering (R.G.)", (0, 2), (0, 2)),
    ("Requirement Analysis & SRS", (0, 2), (0, 3)),
    ("System Design (Use Case, DB, UI)", (0, 3), (0, 4)),
    ("Environment & Docker Setup", (0, 3), (0, 3)),
    ("Coding / Development", (0, 3), (1, 3)),
    ("UI Enhancement (Themes, Mobile)", (1, 3), (1, 4)),
    ("Testing", (1, 3), (2, 1)),
    ("Implementation / Deployment", (2, 1), (2, 2)),
    ("Documentation", (0, 2), (3, 1)),
    ("Final Review, Submission & Viva", (2, 4), (3, 2)),
]

# ---------------------------------------------------------------- data dictionary
# (table name, purpose, [(column, type, constraints, description, example of record id = 1)])
DATA_DICT = [
 ("users", "Stores the login account, role and status of every person who uses the system.", [
   ("id", "INTEGER", "PRIMARY KEY, AUTO INCREMENT", "Unique user identifier", "1"),
   ("name", "VARCHAR(100)", "NOT NULL", "Full name of the user", "Admin"),
   ("email", "VARCHAR(100)", "NOT NULL, UNIQUE, INDEX", "Login e-mail address", "admin@chainshield.com"),
   ("password_hash", "VARCHAR(255)", "NOT NULL", "Werkzeug (scrypt) hash of the password — never plain text", "scrypt:32768:8:1$jCqB…"),
   ("role", "VARCHAR(20)", "NOT NULL, DEFAULT 'manager'", "admin / manager / captain / pilot / driver / loco_pilot", "admin"),
   ("phone", "VARCHAR(20)", "NULL", "Contact number", "9876543210"),
   ("is_active", "BOOLEAN", "NOT NULL, DEFAULT 1", "0 = deactivated by an admin; cannot log in", "1"),
   ("created_at", "DATETIME", "DEFAULT current UTC time", "Account creation time", "2026-08-25 03:48:26"),
 ]),
 ("hubs", "Master data of logistics hubs (base cities) used for plotting, rerouting and holding shipments.", [
   ("id", "INTEGER", "PRIMARY KEY, AUTO INCREMENT", "Unique hub identifier", "1"),
   ("name", "VARCHAR(100)", "NOT NULL", "Name of the hub", "Ahmedabad Hub"),
   ("location", "VARCHAR(150)", "NULL", "City and state of the hub", "Ahmedabad, Gujarat"),
   ("lat", "FLOAT", "NULL", "Latitude — map marker and detour distance", "23.0225"),
   ("lng", "FLOAT", "NULL", "Longitude — map marker and detour distance", "72.5714"),
 ]),
 ("cargo_types", "Master data of cargo categories and how sensitive each one is to disruption.", [
   ("id", "INTEGER", "PRIMARY KEY, AUTO INCREMENT", "Unique cargo type identifier", "1"),
   ("name", "VARCHAR(50)", "NOT NULL, UNIQUE", "Cargo category name", "General"),
   ("sensitivity_weight", "FLOAT", "DEFAULT 0.5, range 0.0 – 1.0", "× 100 gives the cargo factor of the risk score", "0.3"),
 ]),
 ("shipments", "Every shipment with its route, cargo, assigned operator, live position and current risk.", [
   ("id", "INTEGER", "PRIMARY KEY, AUTO INCREMENT", "Unique shipment identifier", "1"),
   ("tracking_no", "VARCHAR(30)", "NOT NULL, UNIQUE", "Tracking number (auto-generated CS-xxxx if blank)", "CS-1001"),
   ("origin", "VARCHAR(100)", "NULL", "Origin city", "Ahmedabad"),
   ("destination", "VARCHAR(100)", "NULL", "Destination city", "Mumbai"),
   ("cargo_type_id", "INTEGER", "FOREIGN KEY → cargo_types.id", "Type of cargo carried", "2 (Perishable)"),
   ("transport_mode", "VARCHAR(20)", "NULL", "Road / Rail / Sea / Air", "Road"),
   ("status", "VARCHAR(20)", "DEFAULT 'In-transit'", "In-transit / Delayed / On-hold / Delivered", "In-transit"),
   ("current_lat", "FLOAT", "NULL", "Current latitude (simulated movement)", "21.1702"),
   ("current_lng", "FLOAT", "NULL", "Current longitude (simulated movement)", "72.8311"),
   ("risk_score", "FLOAT", "DEFAULT 0.0", "Composite risk score 0 – 100 from the last scan", "55.98"),
   ("risk_level", "VARCHAR(15)", "DEFAULT 'LOW'", "LOW / AT-RISK / MEDIUM / HIGH", "MEDIUM"),
   ("cargo_value", "FLOAT", "DEFAULT 0.0", "Declared cargo value in ₹ (value-at-risk)", "85000.00"),
   ("assigned_operator_id", "INTEGER", "FOREIGN KEY → users.id", "Field operator responsible for the shipment", "8 (Suresh Yadav, driver)"),
   ("hub_id", "INTEGER", "FOREIGN KEY → hubs.id", "Origin hub", "1 (Ahmedabad Hub)"),
   ("created_at", "DATETIME", "DEFAULT current UTC time", "Shipment creation time", "2026-09-07 06:24:35"),
 ]),
 ("disruptions", "Disruptions opened automatically by the risk engine for a shipment.", [
   ("id", "INTEGER", "PRIMARY KEY, AUTO INCREMENT", "Unique disruption identifier", "1"),
   ("shipment_id", "INTEGER", "NOT NULL, FOREIGN KEY → shipments.id", "Affected shipment", "1 (CS-1001)"),
   ("type", "VARCHAR(30)", "NULL", "Dominant factor: Weather / Congestion / Cargo / History", "Congestion"),
   ("severity", "VARCHAR(15)", "NULL", "MEDIUM or HIGH (escalated as risk rises)", "MEDIUM"),
   ("risk_score", "FLOAT", "NULL", "Risk score at detection / last escalation", "55.98"),
   ("status", "VARCHAR(15)", "DEFAULT 'Open'", "Open / Resolved", "Resolved"),
   ("detected_at", "DATETIME", "DEFAULT current UTC time", "When the disruption was detected", "2026-09-24 13:07:46"),
   ("resolved_at", "DATETIME", "NULL", "When a route decision was applied", "2026-09-24 13:34:46"),
   ("resolved_by", "INTEGER", "FOREIGN KEY → users.id, NULL", "Manager / admin who resolved it", "5 (Manisha Patel)"),
 ]),
 ("route_solutions", "Ranked route options generated by the route solver for each disruption.", [
   ("id", "INTEGER", "PRIMARY KEY, AUTO INCREMENT", "Unique solution identifier", "1"),
   ("disruption_id", "INTEGER", "NOT NULL, FOREIGN KEY → disruptions.id (cascade delete)", "Parent disruption", "1"),
   ("option_no", "INTEGER", "NOT NULL", "Rank; 1 = recommended option", "1"),
   ("description", "TEXT", "NULL", "Human-readable description of the option", "Reroute via Jaipur Hub (+8 km detour)"),
   ("extra_time_hours", "FLOAT", "NULL", "Additional transit time in hours", "1.5"),
   ("extra_cost", "FLOAT", "NULL", "Additional cost in ₹", "1702.72"),
   ("risk_score", "FLOAT", "NULL", "Residual risk if this option is chosen", "16.73"),
   ("selected", "BOOLEAN", "DEFAULT 0", "1 = option applied by the manager", "1"),
 ]),
 ("notifications", "In-app alerts delivered to individual users in real time.", [
   ("id", "INTEGER", "PRIMARY KEY, AUTO INCREMENT", "Unique notification identifier", "1"),
   ("user_id", "INTEGER", "NOT NULL, FOREIGN KEY → users.id", "Recipient of the alert", "1 (Admin)"),
   ("message", "VARCHAR(255)", "NOT NULL", "Alert text", "MEDIUM risk on CS-1001 (Ahmedabad → Mumbai) — Congestion, score 55.98"),
   ("is_read", "BOOLEAN", "DEFAULT 0", "1 = marked as read", "1"),
   ("created_at", "DATETIME", "DEFAULT current UTC time", "When the alert was created", "2026-09-24 13:07:46"),
 ]),
 ("messages", "Direct chat messages exchanged between two users.", [
   ("id", "INTEGER", "PRIMARY KEY, AUTO INCREMENT", "Unique message identifier", "1"),
   ("sender_id", "INTEGER", "NOT NULL, FOREIGN KEY → users.id", "User who sent the message", "8 (Suresh Yadav)"),
   ("receiver_id", "INTEGER", "NOT NULL, FOREIGN KEY → users.id", "User who receives the message", "1 (Admin)"),
   ("chat_id", "VARCHAR(10)", "NULL", "Conversation key 'lowerId-higherId'", "1-8"),
   ("content", "TEXT", "NOT NULL", "Message text", "Hello"),
   ("sent_at", "DATETIME", "DEFAULT current UTC time", "When the message was sent", "2026-09-24 13:22:49"),
 ]),
 ("activity_log", "Audit trail of logins, administrative actions and disruption decisions.", [
   ("id", "INTEGER", "PRIMARY KEY, AUTO INCREMENT", "Unique log entry identifier", "1"),
   ("user_id", "INTEGER", "FOREIGN KEY → users.id, NULL", "User who performed the action", "1 (Admin)"),
   ("action", "VARCHAR(255)", "NOT NULL", "Description of the action", "Admin resolved the disruption on CS-1002 via 'Hold at current hub'"),
   ("timestamp", "DATETIME", "DEFAULT current UTC time", "When the action happened", "2026-09-07 07:15:49"),
 ]),
]

# ---------------------------------------------------------------- coding standards
# (title, two-line description, example, screenshot, caption)
CODING = [
 ("PEP 8 Naming, Type Hints and Docstrings",
  "All Python code follows PEP 8: 4-space indentation, snake_case for functions and variables, PascalCase for classes and UPPER_CASE for constants. "
  "Functions carry type hints and a docstring, so every member of the group can read and review another member's code without explanation.",
  "compute_risk_score() and classify_risk() in app/services/risk_engine.py; the constant ALERT_LEVELS; the class RouteSolution in app/models.py.",
  "cs1_pep8.png", "Naming, type hints and docstring in the risk engine"),
 ("Application Factory Pattern",
  "The Flask application is never created at import time; create_app() builds it from a named configuration (development, testing or production). "
  "This lets the same code run on a laptop, inside the automated tests and inside Docker, each with its own settings.",
  "create_app(\"testing\") gives the test suite a fresh in-memory database, while Docker calls create_app(\"production\").",
  "cs2_factory.png", "create_app() in app/__init__.py"),
 ("Modular Blueprint Structure",
  "Each feature lives in its own Flask blueprint with its own URL prefix, routes and templates. "
  "A feature can therefore be changed, tested or disabled without touching the others.",
  "shipments_bp serves everything under /shipments, disruptions_bp under /disruptions and chat_bp under /chat.",
  "cs3_blueprints.png", "Blueprint registration in app/__init__.py"),
 ("Single Source of Configuration — No Hard-coded Secrets",
  "Risk weights, the scan interval and model names are defined once in app/config.py; API keys and the secret key are read from a .env file. "
  "The .env file is excluded from Git and Docker, so no password or key is ever committed to the repository.",
  "RISK_WEIGHT_WEATHER = 0.40 is read by the risk engine; GEMINI_API_KEY = os.environ.get(\"GEMINI_API_KEY\", \"\").",
  "cs4_config.png", "Centralised settings in app/config.py"),
 ("ORM Models Instead of Raw SQL",
  "All nine tables are Python classes in app/models.py, and every query goes through Flask-SQLAlchemy. "
  "Queries are parameterised automatically, which prevents SQL injection, and the database can be moved to PostgreSQL by changing only DATABASE_URL.",
  "User.query.filter_by(email=form.email.data).first() instead of a hand-written SELECT statement.",
  "cs5_orm.png", "The User model with password hashing helpers"),
 ("Server-side Form Validation",
  "Every form is validated on the server with Flask-WTF before anything is saved, because browser-side checks can be bypassed. "
  "Business rules that span two fields are written in a validate() method of the form class.",
  "ShipmentForm rejects a shipment whose destination equals its origin and any latitude outside −90 to 90.",
  "cs6_validation.png", "ShipmentForm in app/forms.py"),
 ("Security by Default — Role Decorators",
  "Access rules are written once as decorators and placed on top of each route, so no page can forget its permission check. "
  "Together with CSRF tokens on every form, Werkzeug password hashing and Jinja2 auto-escaping, this protects against the common web attacks.",
  "@manager_required on /shipments/new returns 403 Forbidden to drivers, pilots, captains and loco pilots.",
  "cs7_security.png", "manager_required decorator in the shipments blueprint"),
 ("Template Inheritance and Reusable Macros",
  "base.html defines the sidebar, top bar and scripts once, and every page only fills its content block. "
  "Repeated interface pieces are Jinja2 macros, so a design change is made in exactly one place.",
  "{{ risk_badge(s.risk_level, s.risk_score) }} draws the same coloured risk pill on the dashboard, shipment list and map pop-ups.",
  "cs8_templates.png", "risk_badge macro in app/templates/_macros.html"),
 ("Version Control and Pinned Dependencies",
  "Git records every feature with a descriptive commit message, and every library version is pinned in requirements.txt. "
  "The Dockerfile installs exactly these versions on Python 3.10, so the application behaves identically on every machine.",
  "Commit “Add admin CRUD, reports with CSV export, demo mode and map zones”; Flask==3.0.3 in requirements.txt.",
  "cs9_requirements.png", "Pinned dependencies in requirements.txt"),
]

# ---------------------------------------------------------------- sections
S = []
def sec(num, title, level, doc, ppt):
    S.append(dict(num=num, title=title, level=level, doc=doc, ppt=ppt))

# ============ 1 INTRODUCTION
sec("1", "INTRODUCTION", 1, [], None)

sec("1.1", "Problem Definition", 2, [
  P("Logistics companies move hundreds of shipments at the same time across road, rail, sea and air. Every one of these shipments is exposed to risks that are outside the company's control — heavy rain and storms, congestion at hubs and ports, customs holds, vehicle breakdowns and the special handling needs of sensitive cargo such as perishable or hazardous goods."),
  P("In most companies these disruptions are noticed only after a delivery date has already slipped. Managers depend on manual tracking — phone calls to drivers, spreadsheets and e-mail — and learn about a problem only when a customer or a downstream partner reports a missed delivery. By that time the shipment is already late, the alternate routes that were available earlier have narrowed, and the cost of recovery (express freight, penalty clauses and lost customer trust) has multiplied."),
  P("The core problem, therefore, is the absence of a continuously running system that scores the disruption risk of every active shipment, warns the right people before the delay actually happens, and recommends a corrective route with its time, cost and risk trade-offs clearly stated. ChainShield Transportation System is designed to fill exactly this gap."),
], dict(points=[
  "Hundreds of shipments move at once across road, rail, sea and air",
  "Exposed to weather, hub/port congestion, customs holds, breakdowns, sensitive cargo",
  "Disruptions are noticed only after the delivery date has slipped",
  "Manual tracking — phone calls, spreadsheets, e-mail",
  "Late detection → fewer route options, higher recovery cost, lost trust",
  "No system scores risk continuously and recommends a corrective route in advance",
]))

sec("1.2", "Objective of the New System", 2, [
  P("The main objective of ChainShield is to move logistics operations from a reactive way of working to a preemptive one. The specific objectives of the new system are described below."),
  B("**Continuous risk analysis** — to analyse weather, route congestion, cargo sensitivity and historic delay data for every active shipment on a fixed schedule, without anyone having to start the check manually.",
    "**Early disruption detection** — to detect and flag a potential disruption before the delivery timeline is compromised, using a transparent, weighted risk-scoring formula.",
    "**Optimised route recommendations** — to automatically generate ranked alternatives (hold at a hub, reroute through another hub, or switch the transport mode) the moment a shipment crosses the risk threshold.",
    "**Instant communication** — to notify managers and the assigned field operator in real time when a disruption is detected, escalated or resolved, closing the gap between decision and execution.",
    "**Role-based working** — to give administrators, managers and field operators (drivers, loco pilots, pilots and captains) their own dashboards containing only the information relevant to their work.",
    "**Low-cost deployment** — to keep the system self-contained and inexpensive, built on an open-source Python/Flask stack and packaged with Docker so that any logistics company can run it on its own server."),
], dict(points=[
  "Continuously analyse weather, congestion, cargo and history for every shipment",
  "Detect disruptions early with a transparent weighted risk score",
  "Auto-generate ranked route options: hold, hub reroute, mode switch",
  "Notify managers and field operators in real time",
  "Role-based dashboards for Admin, Manager and Field Operator",
  "Low-cost, self-hosted deployment with Flask + Docker",
]))

sec("1.3", "Core Components", 2, [
  P("ChainShield is made up of seven major components. Each component is implemented as a separate module so that it can be developed and tested independently."),
  B("**Risk Engine** — a scheduled background job that scores every active shipment every 60 seconds using a four-factor weighted model (weather severity, route congestion, cargo sensitivity and historic delay probability) and classifies it as LOW, AT-RISK, MEDIUM or HIGH.",
    "**Disruption Manager** — converts a MEDIUM-or-higher risk score into a formal disruption record, escalates it to HIGH if the risk keeps rising, and asks the route solver for alternatives.",
    "**Route Solver** — builds hold, hub-reroute and mode-switch alternatives using great-circle distances between hubs, and ranks them by a weighted score of residual risk, extra time and extra cost in rupees.",
    "**Notification and Chat Module** — pushes real-time alerts over Flask-SocketIO to admins, managers and the assigned field operator, and lets users send direct messages to each other.",
    "**Admin Panel and Reports** — manages users, logistics hubs and cargo types, keeps an activity audit log, and produces reports with date-range filters and CSV export.",
    "**AI Assistant** — a conversational assistant based on the Google Gemini API, with an offline fallback engine, that answers natural-language questions using live shipment and disruption data.",
    "**Live Map** — a Leaflet.js map of shipment positions, planned routes, hubs and shaded disruption zones that refreshes automatically after every risk scan."),
], dict(points=[
  "Risk Engine — 4-factor score every 60 s",
  "Disruption Manager — opens at MEDIUM, escalates at HIGH",
  "Route Solver — hold / hub reroute / mode switch, ranked",
  "Notifications & Chat — real-time over Socket.IO",
  "Admin Panel & Reports — users, hubs, cargo, audit log, CSV",
  "AI Assistant — Gemini with offline fallback",
  "Live Map — positions, routes, disruption zones",
]))

PROFILE_ROWS = [
  ("Project Title", TITLE),
  ("Project Group", GROUP),
  ("Team Members", "\n".join(f"{n}  (Roll No. {r}, Enrollment No. {e})" for n, r, e in MEMBERS)),
  ("Project Guide", GUIDE),
  ("Domain", "Logistics & Supply Chain Management — real-time disruption prediction and route optimisation"),
  ("Project Description", "A web-based system that continuously scores active shipments for disruption risk, opens disruptions automatically, recommends ranked route alternatives and notifies the responsible people in real time, with role-based dashboards for admins, managers and field operators."),
  ("Front End", "HTML5, CSS3, Bootstrap 5, Jinja2 templates, JavaScript, Leaflet.js, Chart.js"),
  ("Back End", "Python 3.10, Flask, Flask-SQLAlchemy"),
  ("Database", "SQLite"),
  ("Other Tools & APIs", "Flask-Login, Flask-SocketIO, Flask-WTF, APScheduler, Google Gemini API, OpenWeatherMap API, Docker, Git / GitHub"),
  ("Platform", "Windows 11 / any operating system that supports Docker"),
  ("Duration", "August 2026 – November 2026 (Semester 3)"),
  ("Submitted To", f"{INSTITUTE} ({UNIVERSITY})"),
  ("Academic Year", YEAR),
]
sec("1.4", "Project Profile", 2, [
  P("The project profile below gives a one-page summary of the project, the team that developed it and the technologies used."),
  T(["Particulars", "Details"], PROFILE_ROWS, widths=[1.9, 4.6], caption="Table 1.1 — Project Profile", font=11, shade_first_col=True),
], dict(table=(["Particulars", "Details"], [
  ("Project Title", TITLE), ("Group", GROUP),
  ("Team Members", "Bhavik A. Visani (D51) · Diya Shah (D36) · Shruti Somani (D42)"),
  ("Guide", GUIDE), ("Domain", "Logistics & Supply Chain Management"),
  ("Front End", "HTML5, CSS3, Bootstrap 5, Jinja2, JavaScript, Leaflet.js, Chart.js"),
  ("Back End / DB", "Python 3.10, Flask, Flask-SQLAlchemy / SQLite"),
  ("Tools & APIs", "Socket.IO, APScheduler, Gemini API, OpenWeatherMap, Docker, Git"),
  ("Duration", "Aug 2026 – Nov 2026 (Semester 3)"),
])))

sec("1.5", "Need of the New System", 2, [
  P("A study of how logistics teams currently track their shipments showed several weaknesses in the existing, largely manual process. These weaknesses create the need for the new system."),
  B("**Reactive monitoring** — disruptions surface only after a customer complaint or a missed delivery commitment, when recovery options are already limited and expensive.",
    "**Tracking without prediction** — existing tracking screens show where a shipment is, but not what is about to go wrong with it. There is a clear gap between tracking and prediction.",
    "**Signals in silos** — weather, congestion, cargo type and past delay information sit in different places, and no single process combines them into one actionable risk score per shipment.",
    "**Ad hoc rerouting** — rerouting decisions depend on a manager's personal experience instead of a systematic comparison of options with their time, cost and risk clearly quantified.",
    "**Slow communication** — field operators usually learn about a rerouting decision late, over a phone call or radio, which adds further delay and the chance of miscommunication.",
    "**No audit trail** — there is no reliable record of who took which decision and when, which makes review and accountability difficult."),
], dict(points=[
  "Reactive monitoring — problems found after complaints",
  "Tracking shows location, not upcoming risk",
  "Weather, congestion, cargo and history data in silos",
  "Rerouting based on guesswork, not data",
  "Operators informed late by phone or radio",
  "No audit trail of decisions",
]))

sec("1.6", "Scope of the New System", 2, [
  P("The scope defines what the current version of ChainShield covers and what is intentionally left for future versions."),
  H3("Included in the scope"),
  B("Interval-based (near-real-time) risk scoring of every active shipment.",
    "Automatic creation of a disruption when a shipment crosses the risk threshold, with ranked reroute and hold solutions.",
    "A manager dashboard for reviewing and resolving disruptions, and a field-operator dashboard for status updates and resolution notifications.",
    "An admin panel for managing users, hubs and cargo types, along with an activity audit log.",
    "Shipment management (create, view, edit and delete) with server-side validation.",
    "Reports with date-range filters and CSV export — disruption summary, resolution time, shipment risk and audit log.",
    "An AI assistant for natural-language questions about shipment data, and a live map of shipments and disruption zones.",
    "A demo mode — simulated shipment movement, a one-click “Trigger demo disruption” action and a reset command — so the system can be demonstrated without live production data."),
  H3("Outside the scope of the current version"),
  B("Integration with live carrier GPS or telematics hardware (simulated positions are used instead).",
    "Payment, billing and contractual SLA-enforcement modules.",
    "Multi-tenant support for several independent companies on one installation."),
], dict(two=( "In scope", [
  "Risk scoring of every active shipment",
  "Auto disruption + ranked route solutions",
  "Manager, operator and admin dashboards",
  "Shipment CRUD with validation",
  "Reports with date filter + CSV export",
  "AI assistant and live map",
  "Demo mode for presentations"],
  "Out of scope", [
  "Live GPS / telematics hardware",
  "Payment, billing and SLA modules",
  "Multi-tenant (many companies)"])))

sec("1.7", "Advantages and Limitations of the Proposed System", 2, [
  H3("Advantages"),
  B("**Preemptive handling** — the organisation reacts to a risk before it becomes a delay, instead of after the delivery has been missed.",
    "**Transparent scoring** — risk is measured with a clear, weighted formula that anyone can verify, instead of by gut feeling.",
    "**Faster response** — the time between “risk detected” and “operator notified” is reduced to a few seconds.",
    "**Less information overload** — role-based views show each user only what is relevant to their job.",
    "**Cheap and portable** — the lightweight Flask and SQLite stack runs inside a single Docker container, so it is inexpensive to host and easy to set up on any machine."),
  H3("Limitations"),
  B("**Near-real-time, not instantaneous** — freshness depends on the scheduler interval, which is 60 seconds by default.",
    "**Data quality** — weather and congestion signals come from public APIs or a simulated fallback rather than certified logistics-grade data feeds.",
    "**Single-server database** — SQLite suits one server; a large multi-branch deployment would need PostgreSQL or MySQL.",
    "**AI answers are advisory** — the assistant is only as reliable as the Gemini model and the data given to it; it is a convenience feature, not a system of record."),
], dict(two=("Advantages", [
  "Preemptive, not reactive",
  "Transparent weighted scoring",
  "Operator notified within seconds",
  "Role-based views, less overload",
  "Cheap, portable Docker deployment"],
  "Limitations", [
  "Near-real-time (60 s interval)",
  "Public / simulated data feeds",
  "SQLite — single server only",
  "AI answers are advisory"])))

sec("1.8", "Proposed Time Line Chart", 2, [
  P("The project was planned phase-wise across the semester, from August to November 2026. In the chart below each month is divided into four weeks (W1 – W4) and the shaded cells show the weeks in which each phase is carried out. Documentation runs in parallel with every other phase, from requirement gathering until final submission."),
  GANTT(),
  P("Table 1.2 records the milestones actually achieved against this plan, taken from the project's version-control history and document records."),
  T(["Milestone", "Completed On", "Status"], [
    ("Requirement gathering, problem analysis and technology stack decision", "13 Aug 2026", "Done"),
    ("Requirement analysis and system design in the project report", "15 – 19 Aug 2026", "Done"),
    ("Development environment and Docker setup", "16 Aug 2026", "Done"),
    ("Authentication and base user interface", "16 – 25 Aug 2026", "Done"),
    ("SRS document and first presentation", "25 Aug 2026", "Done"),
    ("Risk engine scan loop, route solver, disruption module, admin panel", "7 – 8 Sep 2026", "Done"),
    ("Shipment CRUD, live map, dashboards, charts, real-time notifications", "9 – 16 Sep 2026", "Done"),
    ("Reports with CSV export, cargo/hub/user management, demo mode", "17 – 20 Sep 2026", "Done"),
    ("Testing (101 automated checks) and Docker deployment verification", "21 – 22 Sep 2026", "Done"),
    ("UI enhancement — responsive layout, light/dark themes, animations", "22 – 24 Sep 2026", "Done"),
    ("Final documentation revised as per guide's review", "30 Sep 2026", "Done"),
    ("Final submission and viva", "As per university schedule", "Pending"),
  ], widths=[4.0, 1.6, 0.9], caption="Table 1.2 — Actual Progress Against the Plan", font=10.5),
], dict(gantt=True))

sec("1.9", "Targeted Users", 2, [
  P("ChainShield is designed for the people who plan, supervise and carry out the movement of goods inside a logistics company. Each type of user has a different responsibility, and the system gives each of them a separate, role-based view. The targeted users are described in detail below."),
  H3("1. System Administrator"),
  P("The administrator is the person responsible for setting up and maintaining the system for the whole company — usually a member of the IT or operations-support team. The administrator creates user accounts and assigns their roles, activates or deactivates accounts, maintains the master data of logistics hubs (base cities) and cargo types along with their sensitivity weights, and reviews the system configuration such as the risk weights and API integrations. The administrator also has access to every report and to the complete activity audit log, which records logins, administrative changes and disruption decisions. Because the administrator also inherits all the rights of a manager, he or she can step in to resolve a disruption when needed. Only an existing administrator can create another administrator — admin rights can never be self-assigned at registration."),
  H3("2. Logistics / Supply Chain Manager"),
  P("The manager is the primary decision-maker and the main user of ChainShield. Managers create and update shipments, assign each shipment to a field operator, and watch the dashboard, the risk watch-list and the live map to see which shipments are heading towards trouble. When the risk engine opens a disruption, the manager receives an instant alert, compares the ranked route options (with their extra time, extra cost and residual risk) and applies the most suitable one with a single click. Managers can also ask the AI assistant questions such as “Which shipments are at high risk?”, view and export reports for a chosen date range, trigger a demo disruption during presentations, and chat directly with field operators. For the manager, the system replaces phone calls and spreadsheets with a single, data-driven control screen."),
  H3("3. Field Operators — Driver, Loco Pilot, Pilot and Captain"),
  P("Field operators are the people who physically move the cargo: truck drivers for road shipments, loco pilots for rail, pilots for air cargo and ship captains for sea freight. They are usually on the move and need a simple, mobile-friendly view. After logging in, a field operator sees only the shipments assigned to him or her, their current risk level and position on the live map. Operators update the status of a shipment (In-transit, Delayed, On-hold or Delivered), and the moment a manager resolves a disruption on their shipment they receive a real-time notification describing the new route or the hold instruction. They can also chat directly with their manager or the admin to clarify instructions. This removes the delay and confusion of passing instructions over the phone or radio."),
  H3("4. Background Scheduler (System Actor)"),
  P("Although it is not a human user, the background scheduler is an important actor of the system. It wakes up every 60 seconds, recalculates the risk score of every in-transit shipment, opens or escalates disruptions, asks the route solver for alternatives and triggers the notifications — all without any human action."),
  H3("5. Indirect Beneficiaries"),
  P("End customers, consignees and downstream business partners do not log in to ChainShield, but they benefit directly from fewer missed deliveries and more reliable delivery estimates. Company management also benefits from the reports on disruption frequency, resolution time and value at risk, which support planning and performance review."),
  T(["User", "Main Responsibilities", "Access in ChainShield"], [
    ("Administrator", "System set-up, users, master data, audit", "Full access — admin panel, all reports, audit log, plus all manager functions"),
    ("Manager", "Shipment planning, disruption decisions", "Shipments CRUD, disruptions, route decisions, reports, AI assistant, chat, live map"),
    ("Field Operator (Driver / Loco Pilot / Pilot / Captain)", "Moving the cargo, status updates", "Own assigned shipments only, status update, notifications, chat, live map"),
    ("Scheduler (system)", "Automatic risk scanning", "Risk engine, disruption creation, route generation, alerts"),
  ], widths=[1.8, 2.1, 2.6], caption="Table 1.3 — Targeted Users and Their Access", font=10.5),
], dict(points=[
  "Administrator — users & roles, hubs, cargo types, config, audit log; all manager rights",
  "Manager — creates shipments, reviews disruptions, applies route solution, reports, AI",
  "Field Operators — Driver (road), Loco Pilot (rail), Pilot (air), Captain (sea)",
  "Operators see only their shipments, update status, get instant route alerts, chat",
  "Scheduler (system actor) — scans risk every 60 s, opens disruptions, sends alerts",
  "Indirect — customers, partners and management benefit from fewer delays",
]))

# ============ 2 REQUIREMENTS
sec("2", "REQUIREMENT DETERMINATION AND ANALYSIS", 1, [], None)

sec("2.1", "Requirement Determination", 2, [
  P("The requirements of ChainShield Transportation System were determined through group discussion, a study of how logistics operators track shipments today (manual follow-ups, spreadsheets and phone calls), and an analysis of the roles involved — administrators, operations managers and field operators (drivers, loco pilots, pilots and ship captains)."),
  P("The group divided the problem into three questions: what a supply-chain manager needs to see, what a field operator needs to act on, and what an administrator needs to configure. Each requirement was then checked against the main objective of catching disruptions before they cascade, rather than after. The key requirements identified through this process are:"),
  N("All users (admin, manager and field operator) must log in before they can access the system.",
    "The system must continuously evaluate the risk of every active shipment without anyone triggering it manually.",
    "A disruption must be created automatically when a shipment's risk score reaches MEDIUM (≥ 50), and escalated when it rises to HIGH (≥ 70).",
    "The system must propose at least three ranked route alternatives for every disruption (hold, reroute through a hub, mode switch or continue).",
    "Field operators must be notified in the application the moment a manager resolves a disruption on their shipment.",
    "Administrators must be able to manage users, hubs and cargo types, and view an audit trail of system activity.",
    "The system must be demonstrable without live production data, through a simulated demo-disruption trigger."),
], dict(points=[
  "Sources: group discussion, study of manual tracking, analysis of user roles",
  "Login required for every user",
  "Continuous, automatic risk evaluation",
  "Auto disruption at MEDIUM (≥ 50), escalation at HIGH (≥ 70)",
  "≥ 3 ranked route alternatives per disruption",
  "Instant notification to field operators",
  "Admin management + audit trail; demo mode",
]))

sec("2.2", "Requirement Specification", 2, [
  H3("Functional Requirements"),
  P("Functional requirements describe what the system must do:"),
  N("User registration, login and role-based access control (Admin, Manager, Field Operator).",
    "Create, view, update and delete shipments (managers and admins); field operators see only their assigned shipments.",
    "Continuous, scheduled risk scoring of all active shipments.",
    "Automatic disruption detection and alerting once a risk threshold is crossed.",
    "Generation of ranked route alternatives (hold, hub reroute, mode switch, continue) with cost, time and residual-risk trade-offs.",
    "Real-time in-app notifications (Socket.IO) to managers and the assigned field operator on detection, escalation and resolution of a disruption.",
    "Direct messaging (chat) between users.",
    "Admin CRUD operations for users, logistics hubs and cargo types.",
    "Activity audit log of all administrative and disruption-resolution actions.",
    "AI assistant for natural-language questions about the supply chain.",
    "Reports with a date-range filter and CSV export.",
    "Live map of shipment positions and disruption zones.",
    "A one-click demo-mode trigger for presentations."),
  H3("Non-Functional Requirements"),
  P("Non-functional requirements describe how well the system must perform:"),
  B("**Performance** — risk scores must be refreshed at least once every 60 seconds.",
    "**Usability** — each role sees a dashboard tailored to its work; the interface is responsive from phone to desktop, offers light and dark themes and respects the reduced-motion accessibility setting.",
    "**Portability** — the system must run identically on any machine through Docker, without manual environment setup.",
    "**Reliability** — database writes must be transactional, and the background scheduler must recover gracefully from a failed run.",
    "**Security** — passwords are stored only as hashes; sessions are managed by Flask-Login; all forms are CSRF-protected; admin rights cannot be self-assigned at registration.",
    "**Maintainability** — code is organised into modular Flask blueprints so features can be extended independently."),
  H3("Hardware and Software Requirements"),
  T(["Component", "Specification"], [
    ("Processor / RAM", "Intel i3 or equivalent / minimum 4 GB RAM (8 GB recommended)"),
    ("Operating System", "Windows 11 / any operating system supporting Docker"),
    ("Backend Language", "Python 3.10"),
    ("Web Framework", "Flask, Flask-SQLAlchemy, Flask-Login, Flask-SocketIO, Flask-WTF, APScheduler"),
    ("Database", "SQLite"),
    ("Containerisation", "Docker, Docker Compose (Gunicorn + eventlet worker)"),
    ("Front-End Tools", "HTML5, CSS3, Bootstrap 5, Bootstrap Icons, Jinja2, JavaScript, Leaflet.js, Chart.js"),
    ("External APIs", "Google Gemini API, OpenWeatherMap API"),
    ("Browser", "Google Chrome / Microsoft Edge / Mozilla Firefox (latest)"),
    ("Documentation Tool", "Microsoft Word 2021, Microsoft PowerPoint 2021"),
  ], widths=[1.9, 4.6], caption="Table 2.1 — Hardware and Software Requirements", font=11, shade_first_col=True),
], dict(three=("Functional", [
  "Login + role-based access", "Shipment CRUD", "Scheduled risk scoring", "Auto disruption alerts",
  "Ranked route solutions", "Real-time notifications & chat", "Admin CRUD + audit log",
  "AI assistant, reports + CSV, live map"],
  "Non-Functional", [
  "Performance — refresh ≤ 60 s", "Usability — responsive, themes", "Portability — Docker",
  "Reliability — transactional", "Security — hashing, CSRF, roles", "Maintainability — blueprints"],
  "Platform", [
  "Python 3.10 + Flask", "SQLite", "Bootstrap 5, Leaflet, Chart.js", "Docker + Gunicorn",
  "Gemini + OpenWeatherMap", "Windows 11 / any Docker OS"])))

# ============ 3 SYSTEM DESIGN
sec("3", "SYSTEM DESIGN", 1, [], None)

sec("3.1", "Use Case Diagram", 2, [
  P("The use case diagram (Fig 3.1) shows what each actor can do inside the boundary of ChainShield Transportation System. It has three human actors — Admin, Manager and Field Operator — and one system actor, the Scheduler. Every association is drawn as a straight line and no two lines overlap."),
  I("usecase.png", "Fig 3.1 — Use Case Diagram", 5.6),
  H3("Actors and generalization"),
  P("The three human actors are connected by generalization (the hollow triangle). A Manager is a specialised Field Operator, and an Admin is a specialised Manager. This means the Manager automatically inherits all Field Operator use cases (Login, View Assigned Shipments, Update Shipment Status, View Live Map, Chat with Users and Receive Notifications), and the Admin inherits everything a Manager can do. Because of this, each actor is connected only to the use cases that are new for that role, which keeps the diagram free of crossing lines."),
  H3("Example of «include»"),
  P("“Detect & Escalate Disruption” «include» “Generate Route Solutions”. An include relationship means the included use case is always performed as a mandatory part of the base use case. Whenever the Scheduler detects or escalates a disruption, the route solver is always run to generate the ranked hold, reroute and mode-switch options — a disruption is never created without them."),
  H3("Example of «extend»"),
  P("“Export Report (CSV)” «extend» “View Reports”. An extend relationship means the extending use case is optional and happens only under a certain condition. A manager normally just views a report on screen; only if he or she clicks the Export CSV button is the report additionally downloaded as a CSV file. The arrow points from the optional behaviour to the base use case."),
  H3("System Architecture"),
  P("The system follows a layered architecture (Fig 3.2): a Flask + Jinja2 + Bootstrap presentation layer (with Leaflet.js and Chart.js) talks to the server over HTTP and WebSockets; core services (Risk Engine, Route Solver, Notifications/Chat, AI Assistant, Admin and Reports) form the middle layer; a Flask-SQLAlchemy data-access layer sits below them; and a SQLite database forms the base. The entire stack is packaged inside one Docker container."),
  I("architecture.png", "Fig 3.2 — ChainShield System Architecture", 6.0),
], dict(img="usecase.png", side=[
  "Actors: Admin, Manager, Field Operator, Scheduler",
  "Generalization: Admin → Manager → Field Operator (inherits use cases)",
  "«include»: Detect & Escalate Disruption → Generate Route Solutions (always)",
  "«extend»: Export Report (CSV) → View Reports (optional)",
  "Straight lines, no overlapping",
], extra=dict(title="System Architecture", img="architecture.png")))

DD_DOC = [P("The database of ChainShield is named chainshield and is stored in the SQLite file instance/chainshield.db. It contains nine tables, one for each model class in app/models.py. For every table, the data dictionary below lists each column with its data type, constraints and description, and the last column shows sample data for one record (id = 1), based on the demo data.")]
for i, (tname, purpose, cols) in enumerate(DATA_DICT, 1):
    DD_DOC.append(H3(f"{i}. Table: {tname}"))
    DD_DOC.append(P(purpose))
    DD_DOC.append(T(["Column Name", "Data Type", "Constraints", "Description", "Sample (id = 1)"],
                    [c for c in cols], widths=[1.3, 1.12, 1.45, 1.4, 1.0], font=9,
                    caption=f"Table 3.{i} — {tname}"))
DD_DOC.append(H3("Relationships"))
DD_DOC.append(P("users 1 : N shipments (assigned_operator_id); cargo_types 1 : N shipments; hubs 1 : N shipments; shipments 1 : N disruptions; disruptions 1 : N route_solutions (deleted together with their disruption); users 1 : N notifications, messages (as sender and as receiver), activity_log entries and resolved disruptions."))
sec("3.2", "Data Dictionary", 2, DD_DOC, dict(datadict=True))

sec("3.3", "User Interface Design", 2, [
  P("The user interface is built with server-rendered Jinja2 templates on Bootstrap 5, extended with a custom design system (app/static/css/style.css). Every signed-in page shares one application shell: a collapsible dark sidebar for navigation with live counts, and a top bar with the theme switch, a notification bell and the account menu. The design principles applied to every screen are:"),
  B("**Consistent design system** — Inter typeface, an indigo and teal colour palette, soft shadows and rounded cards. Risk levels always use the same colours: green for LOW, amber for AT-RISK, orange for MEDIUM and red for HIGH.",
    "**Light and dark themes** — switchable from the top bar, defaulting to the operating-system setting; charts and map tiles adapt to the active theme.",
    "**Responsive layout** — the sidebar collapses to icons on desktop and becomes a slide-in drawer on phones, so no page scrolls sideways even at a 390-pixel phone width.",
    "**Feedback and motion** — buttons show a spinner while a form is submitting, KPI numbers count up and new alerts slide in as toasts; motion is switched off automatically for users who prefer reduced motion."),
  H3("Admin Panel Design"),
  P("The admin panel is the control centre of the system and is available only to administrators. It is organised as tabs — Overview, Users, Shipments, Base Cities (hubs), Cargo Types, Reports, System Config and Activity Log — so that every administrative task is one click away. The screenshots below show the main screens of the admin panel."),
  I("admin_dashboard.png", "Fig 3.3 — Admin Panel: Overview Dashboard", 6.2),
  P("The overview dashboard shows KPI cards for active shipments, open disruptions, cargo value at risk and total users, four live Chart.js charts (shipments by risk, by transport mode, disruptions by factor and disruptions over the last 7 days) and the recent activity feed. All figures refresh automatically after every risk scan."),
  I("admin_users.png", "Fig 3.4 — Admin Panel: User Management", 6.2),
  P("The Users tab lists every account with its role and status. The admin can create a new user with a temporary password, change a role, and activate or deactivate an account; a deactivated user is logged out immediately."),
  I("admin_hubs.png", "Fig 3.5 — Admin Panel: Logistics Hubs (Base Cities)", 6.2),
  P("The Base Cities tab maintains the hubs used by the route solver. Each hub has a name, a location and latitude/longitude, which are used to plot the hub on the map and to calculate detour distances."),
  I("admin_cargo.png", "Fig 3.6 — Admin Panel: Cargo Types", 6.2),
  P("The Cargo Types tab maintains the cargo categories and their sensitivity weight between 0.0 and 1.0. A weight outside this range is rejected by server-side validation."),
  I("admin_config.png", "Fig 3.7 — Admin Panel: System Configuration", 6.2),
  P("The System Config tab shows the current risk-engine weights and thresholds, and the status of each integration (OpenWeatherMap, Gemini AI, Socket.IO and demo mode)."),
  I("admin_activity.png", "Fig 3.8 — Admin Panel: Activity Audit Log", 6.2),
  P("The Activity Log tab is a searchable, time-ordered record of logins, administrative changes and disruption decisions, which provides accountability for every action taken in the system."),
], dict(points=[
  "Jinja2 + Bootstrap 5 with a custom design system",
  "Shared shell: collapsible sidebar, top bar, notification bell",
  "Fixed risk colours: LOW green, AT-RISK amber, MEDIUM orange, HIGH red",
  "Light / dark themes, fully responsive",
  "Admin panel tabs: Overview, Users, Shipments, Base Cities, Cargo, Reports, Config, Activity Log",
], shots=[("admin_dashboard.png", "Admin Panel — Overview Dashboard"), ("admin_users.png", "Admin Panel — User Management"),
          ("admin_hubs.png", "Admin Panel — Logistics Hubs"), ("admin_cargo.png", "Admin Panel — Cargo Types"),
          ("admin_config.png", "Admin Panel — System Configuration"), ("admin_activity.png", "Admin Panel — Activity Audit Log")]))

sec("3.4", "Report Design", 2, [
  P("The Reports module is available to administrators and managers. All reports are shown on one screen (Fig 3.9) and are filtered by a From – To date range at the top of the page. Three of the reports can be exported as CSV files that open directly in Microsoft Excel. The design of the reports screen is shown below, followed by the layout of each report."),
  I("reports.png", "Fig 3.9 — Report Design: Reports Screen with Date Filter and CSV Export", 6.2),
  H3("Report 1 — Disruption Summary Report (CSV)"),
  P("On screen this report shows the number of disruptions by dominant factor and by severity for the selected period. The CSV export lists every disruption with its decision details, so management can see which factors cause most disruptions and how each one was handled. Its layout is:"),
  T(["Column", "Description", "Sample Value"], [
    ("ID", "Disruption number", "1"), ("Shipment", "Tracking number", "CS-1001"),
    ("Dominant Factor", "Weather / Congestion / Cargo / History", "Congestion"), ("Severity", "MEDIUM or HIGH", "MEDIUM"),
    ("Risk Score", "Score at detection", "55.98"), ("Status", "Open / Resolved", "Resolved"),
    ("Detected (UTC)", "Detection date and time", "2026-09-24 13:07"), ("Resolved (UTC)", "Decision date and time", "2026-09-24 13:34"),
    ("Resolution Time (h)", "Hours from detection to decision", "0.45"), ("Resolved By", "Manager / admin", "Manisha Patel"),
    ("Chosen Option", "Route option applied", "Reroute via Jaipur Hub (+8 km detour)"),
  ], widths=[1.7, 2.6, 2.2], caption="Table 3.10 — Layout of Disruption Summary Report", font=10),
  H3("Report 2 — Resolution Time by Decision-maker"),
  P("This on-screen report shows, for each manager or admin, how many disruptions were resolved in the period and the average time taken from detection to a route decision. It measures how quickly the team responds to risk."),
  T(["Resolved By", "Count", "Average Time (hours)"], [("Manisha Patel", "4", "0.61"), ("Admin", "2", "1.12")],
    widths=[2.6, 1.6, 2.3], caption="Table 3.11 — Layout of Resolution Time Report (sample rows)", font=10.5),
  H3("Report 3 — Activity Audit Log (CSV)"),
  P("A chronological record of logins, administrative actions, shipment changes and disruption resolutions for the selected period, used for accountability and review."),
  T(["Timestamp (UTC)", "User", "Action"],
    [("2026-09-07 07:15:49", "Admin", "Admin resolved the disruption on CS-1002 via 'Hold at current hub until conditions clear'")],
    widths=[1.5, 1.0, 4.0], caption="Table 3.12 — Layout of Activity Audit Log Report (sample row)", font=10),
  H3("Report 4 — Shipment Risk Report (CSV)"),
  P("This report lists the current risk of every shipment, so a manager can see at a glance which shipments, and how much cargo value, are at risk right now. Its layout is:"),
  T(["Column", "Description", "Sample Value"], [
    ("Tracking No", "Shipment tracking number", "CS-1004"), ("Origin / Destination", "Route of the shipment", "Bengaluru / Chennai"),
    ("Mode", "Road / Rail / Sea / Air", "Air"), ("Cargo Type", "Cargo category", "Electronics"),
    ("Status", "Current shipment status", "In-transit"), ("Risk Level / Score", "Result of the last scan", "MEDIUM / 53.20"),
    ("Cargo Value (INR)", "Declared value", "150000"), ("Operator", "Assigned field operator", "Rohit Mehta"),
    ("Latitude / Longitude", "Current position", "13.08 / 80.27"),
  ], widths=[1.7, 2.6, 2.2], caption="Table 3.13 — Layout of Shipment Risk Report", font=10),
], dict(img="reports.png", side=[
  "Available to Admin and Manager",
  "From – To date-range filter",
  "1. Disruption Summary (CSV)",
  "2. Resolution Time per decision-maker",
  "3. Activity Audit Log (CSV)",
  "4. Shipment Risk (CSV)",
  "CSV opens directly in Excel",
]))

# ============ 4 DEVELOPMENT
sec("4", "DEVELOPMENT", 1, [], None)

CS_DOC = [P("The following coding standards were followed throughout the development of ChainShield. For every standard, a short explanation, an example, and a screenshot of the actual source code where the standard is applied are given.")]
for i, (t, d, ex, img, cap) in enumerate(CODING, 1):
    CS_DOC += [H3(f"{i}. {t}"), P(d), P(f"**Example:** {ex}"), I(img, f"Fig 4.{i} — {cap}", 6.0)]
sec("4.1", "Coding Standards", 2, CS_DOC, dict(coding=True))

sec("4.2", "Implementation Details", 2, [
  H3("Risk Engine (app/services/risk_engine.py)"),
  P("APScheduler runs a scan every 60 seconds (configurable). Each in-transit shipment is scored with the formula: score = 0.40 × weather + 0.25 × congestion + 0.20 × cargo sensitivity + 0.15 × lane history, where each factor is on a scale of 0 – 100. A score of 70 or more is HIGH, 50 or more is MEDIUM, 30 or more is AT-RISK and anything lower is LOW. AT-RISK shipments are only watched; a disruption is opened at MEDIUM and escalated, with re-planned options, if the shipment reaches HIGH. Weather comes from OpenWeatherMap when an API key is configured; otherwise a simulated signal is used. Lane history grows with disruptions on the same origin–destination lane in the last 90 days. In demo mode each scan also moves shipments towards their destination hub, marking them Delivered on arrival."),
  H3("Route Solver (app/services/route_solver.py)"),
  P("For each disruption the solver builds these candidates: hold at the nearest hub, continue on the current route (baseline), reroute through the two hubs with the smallest detour (using the haversine great-circle distance), and a mode switch for the remaining leg (for example Road → Rail). Each option receives an extra time, an extra cost (₹, from per-kilometre mode rates) and a residual risk, and is ranked by 0.60 × risk + 0.25 × normalised time + 0.15 × normalised cost. Option 1 is the recommendation."),
  H3("Real-time Layer (Flask-SocketIO)"),
  P("Every logged-in browser joins a personal room (user_<id>). Notifications and chat messages are saved in the database and pushed to the right room; broadcast events such as shipments_updated and disruption_new make the live map, dashboards and charts refresh themselves without polling."),
  H3("AI Assistant (app/services/assistant.py)"),
  P("The user's question and a snapshot of the live data that the user is allowed to see (shipments, risk, open disruptions and their ranked options) are sent to Google Gemini. Without a key or an internet connection, a rule-based offline engine answers from the same data, so the feature always works during a demonstration."),
  H3("Security and Deployment"),
  P("Passwords are hashed with Werkzeug, sessions are handled by Flask-Login, every form and AJAX call carries a CSRF token, every route checks the user's role, accounts can be deactivated, and nobody can register as admin. The application is packaged as a Docker image on Python 3.10 served by Gunicorn with an eventlet worker (for real WebSockets); the SQLite file is persisted through a Docker volume and secrets are supplied through a .env file that is never committed."),
], dict(points=[
  "Risk Engine: 0.40 W + 0.25 C + 0.20 Cargo + 0.15 History (each 0–100)",
  "Thresholds: ≥70 HIGH, ≥50 MEDIUM, ≥30 AT-RISK, else LOW",
  "Route Solver: hold / continue / 2 hub reroutes / mode switch",
  "Ranking: 0.60 risk + 0.25 time + 0.15 cost → Option 1 recommended",
  "Socket.IO personal rooms; live map & charts refresh without polling",
  "AI Assistant: Gemini on live data, offline fallback",
  "Security: hashing, CSRF, role checks; Docker + Gunicorn + eventlet",
]))

OUT = [("landing.png", "Landing Page"), ("login.png", "Login Screen"), ("register.png", "Registration Screen"),
       ("live_map.png", "Live Shipment Map with Disruption Zones"), ("disruptions.png", "Disruptions with Ranked Route Options"),
       ("shipments.png", "Shipment List"), ("shipment_detail.png", "Shipment Detail with Mini-map and History"),
       ("shipment_form.png", "Create Shipment Form"), ("driver_dashboard.png", "Field Operator (Driver) Dashboard"),
       ("chat.png", "Real-time Team Chat"), ("notifications.png", "Notification Feed"),
       ("assistant.png", "AI Assistant with Suggested Questions"), ("dark_dashboard.png", "Dark Theme — Dashboard"),
       ("dark_map.png", "Dark Theme — Live Map"), ("mobile.png", "Mobile Views — Dashboard, Disruptions, Live Map and Navigation Drawer")]
OUT_START = len(CODING) + 1
OUT_DOC = [P("The screenshots below were captured from the running application with demo data. The admin panel screens are shown in Section 3.3 and the reports screen in Section 3.4.")]
for k, (img, cap) in enumerate(OUT):
    OUT_DOC.append(I(img, f"Fig 4.{OUT_START + k} — {cap}", 6.2))
sec("4.3", "Output Screens", 2, OUT_DOC, dict(outputs=OUT))

# ============ 5 TESTING
TESTS = [
 ("TC001", "User Login", "Verify that a registered user can log in with correct credentials.", "User account exists in the database.", "email = manisha@chainshield.com, password = demo1234", "User is authenticated and redirected to the role-specific dashboard.", "Pass"),
 ("TC002", "Risk Score Calculation", "Verify the risk engine computes the composite score from the 4 factors.", "Weights configured as 0.40 / 0.25 / 0.20 / 0.15.", "Weather = 80, Congestion = 60, Cargo = 50, History = 40", "Score = 0.40×80 + 0.25×60 + 0.20×50 + 0.15×40 = 63 (MEDIUM)", "Pass"),
 ("TC003", "Automatic Disruption & Escalation", "Verify a disruption is auto-created at MEDIUM and escalated at HIGH.", "Scheduler running; in-transit shipment with no open disruption.", "Scan 1: score 55 (MEDIUM); Scan 2: score 74 (HIGH)", "One disruption opened at MEDIUM with ≥ 3 ranked solutions, then escalated to HIGH with re-planned options.", "Pass"),
 ("TC004", "Route Solution & Notification", "Verify resolving a disruption notifies the assigned field operator.", "Open disruption with ranked solutions; manager logged in.", "Manager selects Option 1 “Reroute via Jaipur Hub”", "Disruption becomes Resolved; operator receives a live notification; action logged.", "Pass"),
 ("TC005", "Admin CRUD (Cargo Type)", "Verify admin can add, edit and delete a cargo type.", "Admin logged in.", "name = Pharma, weight 0.9 → 0.85; weight 1.5 (invalid)", "Cargo type saved, edited and deleted; weight outside 0.0–1.0 rejected.", "Pass"),
 ("TC006", "Docker Container Startup", "Verify the application starts inside Docker.", "Docker Desktop on Windows 11.", "docker compose up --build", "Image builds; Gunicorn + eventlet starts on port 5000; /health returns ok.", "Pass"),
 ("TC007", "Role-Based Access Control", "Verify field operators cannot reach admin/manager pages.", "Driver account with 3 assigned shipments.", "GET /dashboard/users, /shipments/new, /reports", "403 Forbidden for admin/manager pages; 404 for other operators' shipments.", "Pass"),
 ("TC008", "Real-time Chat Delivery", "Verify a chat message is stored and delivered live.", "Admin and driver logged in (two browsers).", "Admin sends “Hold CS-1001 at Surat”", "Message saved and appears instantly in the driver's open chat.", "Pass"),
 ("TC009", "AI Assistant with Fallback", "Verify the assistant answers from live data, with or without Gemini.", "Shipments and open disruptions exist.", "“Give me a summary” with valid and invalid key", "Gemini answer with valid key; offline engine answers with invalid key.", "Pass"),
 ("TC010", "Reports and CSV Export", "Verify reports render and export for managers with date filter.", "Manager logged in; data exists.", "/reports?from=2026-09-01&to=2026-09-30; disruptions.csv", "Four reports shown; CSV opens in Excel; filter limits rows.", "Pass"),
 ("TC011", "User Deactivation", "Verify a deactivated user cannot log in.", "Admin logged in; target user has a session.", "Admin clicks Deactivate", "Login refused with message; open session logged out.", "Pass"),
 ("TC012", "Demo Disruption Trigger", "Verify the demo trigger creates a HIGH disruption instantly.", "Manager logged in; in-transit shipment exists.", "Click “Trigger demo disruption”", "HIGH disruption with ranked options, map zone and live alert appear.", "Pass"),
 ("TC013", "Responsive Layout and Themes", "Verify the UI works on phones and theme preference is kept.", "Browser at 390 × 844 and 1440 × 900.", "Open 8 main pages; toggle dark mode", "No sideways scrolling on phone; drawer works; theme remembered.", "Pass"),
]
TEST_DOC = [P("Testing combined an automated test script (101 checks run through Flask's test client and the Socket.IO test client, covering every route, role restriction, the risk and route-solver logic, real-time events, chat, the assistant, reports and admin CRUD), manual testing of every screen in the browser, and a Docker deployment test. The representative test cases are described below.")]
for tid, name, desc, pre, data, exp, st in TESTS:
    TEST_DOC.append(H3(f"Test Case {int(tid[2:])} — {name}"))
    TEST_DOC.append(T(["Field", "Details"], [("Test ID", tid), ("Description", desc), ("Pre-conditions", pre), ("Test Data", data), ("Expected Result", exp), ("Actual Result", exp), ("Status", st)], widths=[1.6, 4.9], font=10.5, shade_first_col=True))
sec("5", "TESTING", 1, [], None)
sec("5.1", "Test Cases", 2, TEST_DOC, dict(tests=TESTS))

# ============ 6-8
sec("6", "PROPOSED ENHANCEMENT", 1, [
  P("The current version fulfils the objectives of the MCA Semester 3 project. The following enhancements have been identified as valuable future work:"),
  B("**Real GPS / telematics integration** — replace simulated shipment positions with live feeds from vehicle trackers.",
    "**PostgreSQL database** — migrate from SQLite for multi-server, production-scale deployment.",
    "**Machine-learning risk model** — train a predictive model on historical disruption data to support or replace the current weighted formula.",
    "**Mobile app / PWA for field operators** — an installable app with push notifications for status updates on the move.",
    "**Multi-tenant support** — let several independent logistics companies use isolated instances of the platform.",
    "**More notification channels** — SMS and WhatsApp alerts alongside in-app notifications.",
    "**Customs and port-authority APIs** — verified real-time congestion data.",
    "**Smarter AI assistant** — better prompts, conversation memory and suggested actions.",
    "**PDF reports and scheduled e-mails** — PDF export and a daily risk-summary e-mail."),
], dict(points=[
  "Real GPS / telematics feeds", "PostgreSQL for production scale", "ML-based risk prediction",
  "Mobile app / PWA for operators", "Multi-tenant support", "SMS & WhatsApp alerts",
  "Customs & port APIs", "Smarter AI assistant", "PDF reports & scheduled e-mails",
]))

sec("7", "CONCLUSION", 1, [
  P("ChainShield Transportation System addresses a well-defined, real-world problem: supply-chain disruptions are usually discovered only after delivery timelines are already compromised. By continuously scoring every active shipment with a transparent, weighted risk model, and by pairing every detected disruption with concrete, ranked route alternatives, the system moves logistics management from a reactive posture to a preemptive one."),
  P("The system was built from scratch as a self-contained Python (Flask) and SQLite application, containerised with Docker so that it runs identically on any server. This makes it practical for a logistics company to deploy it on its own infrastructure, connect its own weather and AI keys, and start monitoring its shipments immediately."),
  P("Group 59 translated the requirement analysis and system design in this report into a working, tested application: a scheduled risk engine, automatic disruption detection with escalation, a multi-objective route solver, a live map, role-based dashboards, real-time notifications and chat, a Gemini-powered assistant, reports with CSV export, a full admin panel and a responsive interface with light and dark themes — verified by 101 automated checks, visual checks on desktop and phone, and a Docker deployment test."),
], dict(stats=[("4", "Weighted risk factors"), ("9", "Database tables"), ("101", "Automated checks passed"), ("60 s", "Risk scan interval")],
         points=["Moves logistics from reactive to preemptive", "Every disruption paired with ranked route options",
                 "Self-hosted Flask + SQLite + Docker", "Fully built, tested and deployable"]))

sec("8", "BIBLIOGRAPHY", 1, [
  H3("Books Referred"),
  N("Miguel Grinberg, Flask Web Development, 2nd Edition, O'Reilly Media.",
    "Eric Matthes, Python Crash Course, 3rd Edition, No Starch Press.",
    "Ramez Elmasri & Shamkant B. Navathe, Fundamentals of Database Systems, Pearson.",
    "Ian Sommerville, Software Engineering, 10th Edition, Pearson."),
  H3("Websites Referred"),
  N("https://flask.palletsprojects.com/", "https://docs.python.org/3/", "https://www.sqlite.org/docs.html",
    "https://docs.docker.com/", "https://getbootstrap.com/docs/5.3/", "https://leafletjs.com/reference.html",
    "https://flask-socketio.readthedocs.io/", "https://apscheduler.readthedocs.io/", "https://www.chartjs.org/docs/",
    "https://ai.google.dev/gemini-api/docs", "https://openweathermap.org/api", "https://developer.mozilla.org/",
    "https://www.geeksforgeeks.org/"),
], dict(two=("Books", ["Flask Web Development — M. Grinberg", "Python Crash Course — E. Matthes",
                        "Fundamentals of Database Systems — Elmasri & Navathe", "Software Engineering — I. Sommerville"],
             "Websites", ["flask.palletsprojects.com", "docs.python.org", "sqlite.org / docs.docker.com",
                          "getbootstrap.com / leafletjs.com", "flask-socketio / apscheduler docs",
                          "ai.google.dev (Gemini) / openweathermap.org"])))
