# -*- coding: utf-8 -*-
import sys, re
sys.path.insert(0, "/home/claude/w")
from content import *
from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from PIL import Image as PI

F = "Times New Roman"
NAVY = RGBColor(0x1B, 0x2A, 0x4A); TEAL = RGBColor(0x0F, 0x8B, 0x8D); INK = RGBColor(0x22, 0x22, 0x22)
LIGHT = RGBColor(0xEE, 0xF3, 0xFA); MUTED = RGBColor(0x66, 0x6E, 0x7A); WHITE = RGBColor(255, 255, 255)
BLUE = RGBColor(0x2E, 0x5A, 0xAC)
prs = Presentation(); prs.slide_width = Inches(13.333); prs.slide_height = Inches(7.5)
BL = prs.slide_layouts[6]
SW, SH = 13.333, 7.5
count = [0]

def tb(slide, x, y, w, h, text="", size=16, bold=False, color=INK, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP, italic=False):
    s = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h)); tf = s.text_frame; tf.word_wrap = True
    tf.margin_left = tf.margin_right = Inches(0.05); tf.margin_top = tf.margin_bottom = Inches(0.02); tf.vertical_anchor = anchor
    lines = text.split("\n") if isinstance(text, str) else text
    for i, line in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph(); p.alignment = align
        runs(p, line, size, bold, color, italic)
    return s

def runs(p, text, size, bold=False, color=INK, italic=False):
    for part in re.split(r"(\*\*[^*]+\*\*)", text):
        if not part: continue
        b = part.startswith("**"); r = p.add_run(); r.text = part[2:-2] if b else part
        r.font.name = F; r.font.size = Pt(size); r.font.bold = bold or b; r.font.color.rgb = color; r.font.italic = italic

def rect(slide, x, y, w, h, fill, shape=MSO_SHAPE.RECTANGLE, line=None):
    s = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    s.fill.solid(); s.fill.fore_color.rgb = fill
    if line: s.line.color.rgb = line; s.line.width = Pt(1)
    else: s.line.fill.background()
    s.shadow.inherit = False
    return s

def base(section, title):
    s = prs.slides.add_slide(BL); count[0] += 1
    tb(s, 0.6, 0.35, 12, 0.35, section.upper(), 13, True, TEAL)
    tb(s, 0.6, 0.65, 12.1, 0.75, title, 30, True, NAVY)
    rect(s, 0.6, 1.42, 12.13, 0.02, RGBColor(0xC9, 0xD3, 0xE3))
    tb(s, 0.6, 7.05, 9, 0.3, f"{TITLE}  |  MCA Semester 3  |  {GROUP}", 10, color=MUTED)
    tb(s, 11.9, 7.05, 0.85, 0.3, str(count[0]), 10, color=MUTED, align=PP_ALIGN.RIGHT)
    return s

def points(s, pts, x=0.6, y=1.75, w=12.1, size=18, gap=None):
    n = len(pts); gap = gap or min(0.78, 5.1 / max(n, 1))
    for i, t in enumerate(pts):
        yy = y + i * gap
        rect(s, x, yy + 0.1, 0.16, 0.16, TEAL)
        tb(s, x + 0.35, yy, w - 0.35, gap, t, size, color=INK)

def picture(s, path, x, y, maxw, maxh, border=True):
    w, h = PI.open(path).size; r = min(maxw / w, maxh / h); pw, ph = w * r, h * r
    px, py = x + (maxw - pw) / 2, y + (maxh - ph) / 2
    pic = s.shapes.add_picture(path, Inches(px), Inches(py), Inches(pw), Inches(ph))
    if border: pic.line.color.rgb = RGBColor(0xC9, 0xD3, 0xE3); pic.line.width = Pt(0.75)
    return px, py, pw, ph

def table(s, headers, rows, x, y, w, colw, size=12, rowh=0.3, first_bold=False):
    t = s.shapes.add_table(len(rows) + 1, len(headers), Inches(x), Inches(y), Inches(w), Inches(rowh * (len(rows) + 1))).table
    for i, cw in enumerate(colw): t.columns[i].width = Inches(cw)
    for r in range(len(rows) + 1):
        t.rows[r].height = Inches(rowh)
        for c in range(len(headers)):
            cell = t.cell(r, c); val = headers[c] if r == 0 else str(rows[r - 1][c])
            cell.margin_left = cell.margin_right = Inches(0.06); cell.margin_top = cell.margin_bottom = Inches(0.03)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            tf = cell.text_frame; tf.word_wrap = True; tf.paragraphs[0].text = ""
            for li, line in enumerate(val.split("\n")):
                p = tf.paragraphs[0] if li == 0 else tf.add_paragraph()
                runs(p, line, size, bold=(r == 0) or (first_bold and c == 0), color=WHITE if r == 0 else INK)
            cell.fill.solid(); cell.fill.fore_color.rgb = NAVY if r == 0 else (LIGHT if (first_bold and c == 0) or r % 2 == 0 else WHITE)
    return t

def columns(s, groups, y=1.75, h=5.0, size=16):
    n = len(groups); gw = (12.13 - 0.3 * (n - 1)) / n
    for i, (head, items) in enumerate(groups):
        x = 0.6 + i * (gw + 0.3)
        rect(s, x, y, gw, h, LIGHT)
        rect(s, x, y, gw, 0.55, NAVY)
        tb(s, x + 0.15, y + 0.08, gw - 0.3, 0.4, head, 18, True, WHITE)
        gap = min(0.62, (h - 0.8) / len(items))
        for k, it in enumerate(items):
            yy = y + 0.75 + k * gap
            rect(s, x + 0.2, yy + 0.1, 0.13, 0.13, TEAL)
            tb(s, x + 0.45, yy, gw - 0.6, gap, it, size)

chap_of = lambda num: next(c for c in S if c["level"] == 1 and c["num"] == num.split(".")[0])
def label(sct): c = chap_of(sct["num"]); return f"{c['num']}. {c['title']}"

# ================================================================ TITLE
s = prs.slides.add_slide(BL); count[0] += 1
rect(s, 0, 0, SW, SH, NAVY)
tb(s, 0.9, 1.2, 11.5, 0.4, "A PROJECT REPORT ON  ·  MCA SEMESTER 3  ·  " + YEAR, 14, True, RGBColor(0x9F, 0xD8, 0xD9))
tb(s, 0.9, 1.8, 11.5, 1.0, TITLE, 46, True, WHITE)
tb(s, 0.9, 2.85, 11.5, 0.5, SUBTITLE, 22, False, RGBColor(0xDD, 0xE6, 0xF3), italic=True)
rect(s, 0.9, 3.65, 1.4, 0.06, TEAL)
tb(s, 0.9, 4.0, 6.5, 1.8, [f"**Prepared By ({GROUP})**"] + [f"{n}  ({r} – {e})" for n, r, e in MEMBERS], 16, color=WHITE)
tb(s, 7.8, 4.0, 4.8, 1.2, ["**Guided By**", GUIDE], 16, color=WHITE)
tb(s, 0.9, 6.4, 11.5, 0.4, f"{INSTITUTE}  |  Affiliated to {UNIVERSITY}", 14, color=RGBColor(0xDD, 0xE6, 0xF3))

# ================================================================ INDEX
s = base("Contents", "Index")
chs = [c for c in S if c["level"] == 1]
for i, c in enumerate(chs):
    col, row = i // 4, i % 4
    x, y = 0.6 + col * 6.2, 1.8 + row * 1.25
    rect(s, x, y, 0.8, 0.8, NAVY, MSO_SHAPE.OVAL)
    tb(s, x, y, 0.8, 0.8, c["num"], 24, True, WHITE, PP_ALIGN.CENTER, MSO_ANCHOR.MIDDLE)
    subs = [z["title"] for z in S if z["level"] == 2 and z["num"].split(".")[0] == c["num"]]
    tb(s, x + 1.0, y - 0.02, 5.0, 0.4, c["title"].title().replace("And", "and"), 19, True, NAVY)
    if subs: tb(s, x + 1.0, y + 0.38, 5.0, 0.8, " · ".join(subs), 12, color=MUTED)

# ================================================================ SECTIONS
for sct in S:
    p = sct["ppt"]
    if p is None: continue
    ttl = f"{sct['num']} {sct['title'].title() if sct['level']==1 else sct['title']}".replace("And ", "and ")
    lab = label(sct)
    if "points" in p and not any(k in p for k in ("shots", "stats")):
        s = base(lab, ttl); points(s, p["points"])
    if "two" in p:
        s = base(lab, ttl); a, ai, b, bi = p["two"]; columns(s, [(a, ai), (b, bi)])
    if "three" in p:
        s = base(lab, ttl); a, ai, b, bi, c_, ci = p["three"]; columns(s, [(a, ai), (b, bi), (c_, ci)], size=15)
    if "table" in p:
        s = base(lab, ttl); h, rows = p["table"]
        table(s, h, rows, 0.6, 1.75, 12.1, [3.0, 9.1], size=15, rowh=0.52, first_bold=True)
    if p.get("gantt"):
        s = base(lab, ttl)
        weeks = 16; hdr = ["Sr.", "Phase"] + [f"W{k%4+1}" for k in range(weeks)]
        t = s.shapes.add_table(len(GANTT_ROWS) + 2, 18, Inches(0.6), Inches(1.7), Inches(12.1), Inches(4.9)).table
        t.columns[0].width = Inches(0.5); t.columns[1].width = Inches(3.8)
        for k in range(weeks): t.columns[2 + k].width = Inches(7.8 / weeks)
        def cset(r, c, txt, size=12, bold=False, fill=WHITE, color=INK, align=PP_ALIGN.CENTER):
            cell = t.cell(r, c); cell.fill.solid(); cell.fill.fore_color.rgb = fill
            cell.margin_left = cell.margin_right = Inches(0.03); cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            tf = cell.text_frame; tf.paragraphs[0].text = ""; tf.paragraphs[0].alignment = align
            runs(tf.paragraphs[0], txt, size, bold, color)
        t.cell(0, 0).merge(t.cell(1, 0)); t.cell(0, 1).merge(t.cell(1, 1))
        cset(0, 0, "Sr.", 13, True, NAVY, WHITE); cset(0, 1, "Phase", 13, True, NAVY, WHITE, PP_ALIGN.LEFT)
        for m, name in enumerate(MONTHS):
            t.cell(0, 2 + m * 4).merge(t.cell(0, 5 + m * 4)); cset(0, 2 + m * 4, name + " 2026", 13, True, NAVY, WHITE)
            for w in range(4): cset(1, 2 + m * 4 + w, f"W{w+1}", 10, True, RGBColor(0xD9, 0xE2, 0xF1))
        for i, (ph, (sm, sw), (em, ew)) in enumerate(GANTT_ROWS):
            r = i + 2; cset(r, 0, str(i + 1), 12); cset(r, 1, ph, 12, align=PP_ALIGN.LEFT)
            a, b = sm * 4 + sw - 1, em * 4 + ew - 1
            for k in range(weeks): cset(r, 2 + k, "", 8, fill=BLUE if a <= k <= b else WHITE)
        for r in range(len(GANTT_ROWS) + 2): t.rows[r].height = Inches(0.4)
        tb(s, 0.6, 6.55, 12, 0.4, "W1 = days 1–7 · W2 = 8–14 · W3 = 15–21 · W4 = 22 to month-end · Documentation runs through every phase", 12, color=MUTED, italic=True)
    if "img" in p and "side" in p:
        s = base(lab, ttl)
        tall = PI.open(IMG + p["img"]).size[1] > PI.open(IMG + p["img"]).size[0]
        if tall:
            picture(s, IMG + p["img"], 0.6, 1.6, 5.2, 5.35, border=False)
            points(s, p["side"], x=6.3, y=1.9, w=6.4, size=17, gap=0.85)
        else:
            picture(s, IMG + p["img"], 0.6, 1.65, 7.9, 5.25)
            points(s, p["side"], x=8.8, y=1.8, w=3.9, size=16, gap=0.72)
        if "extra" in p:
            s = base(lab, f"{sct['num']} {p['extra']['title']}")
            picture(s, IMG + p["extra"]["img"], 0.6, 1.65, 12.1, 5.25, border=False)
    if p.get("datadict"):
        groups = [["users", "hubs", "cargo_types"], ["shipments"], ["disruptions", "route_solutions"], ["notifications", "messages", "activity_log"]]
        dd = {n: (pu, cols) for n, pu, cols in DATA_DICT}
        for gi, g in enumerate(groups, 1):
            s = base(lab, f"{ttl} ({gi}/{len(groups)}) — Sample record: id = 1")
            if len(g) == 1:
                n = g[0]; pu, cols = dd[n]
                tb(s, 0.6, 1.55, 12, 0.35, f"**Table: {n}** — {pu}", 14, color=INK)
                table(s, ["Column", "Data Type", "Constraints", "Sample (id = 1)"], [(c[0], c[1], c[2], c[4]) for c in cols],
                      0.6, 1.95, 12.1, [2.6, 1.9, 4.2, 3.4], size=11.5, rowh=0.305)
            else:
                ww = (12.13 - 0.25 * (len(g) - 1)) / len(g)
                for k, n in enumerate(g):
                    pu, cols = dd[n]; x = 0.6 + k * (ww + 0.25)
                    tb(s, x, 1.55, ww, 0.35, f"Table: {n}", 15, True, NAVY)
                    table(s, ["Column", "Type", "Sample (id = 1)"], [(c[0], c[1].replace("VARCHAR", "VARCHAR"), c[4]) for c in cols],
                          x, 1.95, ww, [ww * 0.33, ww * 0.31, ww * 0.36], size=10.5 if len(g) == 3 else 12, rowh=0.33)
    if "shots" in p:
        s = base(lab, ttl)
        points(s, p["points"], x=0.6, y=1.75, w=5.2, size=16, gap=0.95)
        img, cap = p["shots"][0]; px, py, pw, ph = picture(s, IMG + img, 6.1, 1.65, 6.6, 4.9)
        tb(s, 6.1, py + ph + 0.05, 6.6, 0.3, cap, 12, color=MUTED, align=PP_ALIGN.CENTER, italic=True)
        rest = p["shots"][1:]
        for j in range(0, len(rest), 2):
            pair = rest[j:j + 2]
            s = base(lab, f"{ttl} — Admin Panel")
            for k, (img, cap) in enumerate(pair):
                x = 0.6 + k * 6.2 if len(pair) == 2 else 1.6
                mw = 5.9 if len(pair) == 2 else 10.1
                px, py, pw, ph = picture(s, IMG + img, x, 1.7, mw, 4.8)
                tb(s, x, py + ph + 0.08, mw, 0.3, cap, 13, color=MUTED, align=PP_ALIGN.CENTER, italic=True)
    if p.get("coding"):
        for i, (t_, d, ex, img, cap) in enumerate(CODING, 1):
            s = base(lab, f"{sct['num']} Coding Standards ({i}/{len(CODING)})")
            tb(s, 0.6, 1.65, 4.7, 0.9, f"{i}. {t_}", 20, True, NAVY)
            first, second = d.split(". ", 1) if ". " in d else (d, "")
            points(s, [first.rstrip(".") + ".", second], x=0.6, y=2.65, w=4.7, size=14, gap=1.35)
            rect(s, 0.6, 5.45, 4.7, 1.35, LIGHT)
            tb(s, 0.75, 5.5, 4.45, 1.25, f"**Example:** {ex}", 13)
            px, py, pw, ph = picture(s, IMG + img, 5.6, 1.7, 7.1, 4.9, border=False)
            tb(s, 5.6, py + ph + 0.05, 7.1, 0.3, "Screenshot — " + cap, 12, color=MUTED, align=PP_ALIGN.CENTER, italic=True)
    if "outputs" in p:
        o = p["outputs"]
        for j in range(0, len(o), 2):
            pair = o[j:j + 2]
            s = base(lab, f"{ttl} ({j//2+1}/{(len(o)+1)//2})")
            for k, (img, cap) in enumerate(pair):
                wide = len(pair) == 1 or PI.open(IMG + img).size[0] / PI.open(IMG + img).size[1] > 1.8
                x = 0.6 + k * 6.2 if len(pair) == 2 else 1.6
                mw = 5.9 if len(pair) == 2 else 10.1
                px, py, pw, ph = picture(s, IMG + img, x, 1.7, mw, 4.8)
                tb(s, x, py + ph + 0.08, mw, 0.3, cap, 13, color=MUTED, align=PP_ALIGN.CENTER, italic=True)
    if "tests" in p:
        tests = p["tests"]
        for part, chunk in enumerate([tests[:7], tests[7:]], 1):
            s = base(lab, f"{ttl} ({part}/2) — 101 automated checks, 0 failures")
            table(s, ["ID", "Test Case", "Test Data", "Expected Result", "Status"],
                  [(a, b, e, f, g) for a, b, c, d, e, f, g in chunk], 0.6, 1.7, 12.1, [0.85, 2.3, 3.3, 4.75, 0.9], size=11.5, rowh=0.62)
    if "stats" in p:
        s = base(lab, ttl)
        for i, (v, l) in enumerate(p["stats"]):
            x = 0.6 + i * 3.08
            rect(s, x, 1.8, 2.83, 1.8, LIGHT)
            tb(s, x, 1.9, 2.83, 1.0, v, 48, True, NAVY, PP_ALIGN.CENTER, MSO_ANCHOR.MIDDLE)
            tb(s, x, 2.95, 2.83, 0.5, l, 15, color=MUTED, align=PP_ALIGN.CENTER)
        points(s, p["points"], x=0.6, y=4.05, w=12.1, size=18, gap=0.68)

# ================================================================ THANK YOU
s = prs.slides.add_slide(BL); count[0] += 1
rect(s, 0, 0, SW, SH, NAVY)
tb(s, 0.9, 2.2, 11.5, 1.2, "Thank You", 54, True, WHITE)
tb(s, 0.9, 3.35, 11.5, 0.6, "Questions & Discussion", 24, color=RGBColor(0xDD, 0xE6, 0xF3), italic=True)
rect(s, 0.9, 4.15, 1.4, 0.06, TEAL)
tb(s, 0.9, 4.5, 11.5, 1.0, ["  ·  ".join(n for n, _, _ in MEMBERS), f"{GROUP}  |  Guided by {GUIDE}  |  {INSTITUTE}"], 16, color=WHITE)

out = "/home/claude/w/out/ChainShield_Presentation_Final_v2.pptx"
prs.save(out); print("slides", count[0], out)
